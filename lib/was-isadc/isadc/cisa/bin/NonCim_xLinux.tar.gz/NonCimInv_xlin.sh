#!/bin/sh
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2009, 2011 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplicate or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.


####################################



####################################
# printChassis
####################################
printChassis()
{
  if [ -f "./biosinfo_linux" ]; then
    chmod +x biosinfo_linux 2>/dev/null
    ./biosinfo_linux 3 2>/dev/null
  fi
  return
}

####################################
# printProcessors
####################################
printProcessors()
{
  if [ -f "./biosinfo_linux" ]; then
    ./biosinfo_linux 4 2>/dev/null
  fi
  return
}

####################################
# printPhysicalMemory
####################################
printPhysicalMemory()
{
  if [ -f "./biosinfo_linux" ]; then
    ./biosinfo_linux 6 2>/dev/null
  fi
  return
}

####################################
# printDiskDrives
####################################
printDiskDrives()
{
  count=0
  for dasd_dir in /sys/block/hd*;
   do
     if [ "$dasd_dir" = "/sys/block/hd*" ]; then
       continue
     fi
     dasd_status=0
     dasd_devid=${dasd_dir#/sys/block/}
     echo "DiskDrive.$count.Name=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceID=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceType=2"
     if [ -f $dasd_dir/size ]; then
       dasd_size=`cat $dasd_dir/size`
       dasd_size=`expr $dasd_size / 2`
       echo "DiskDrive.$count.Capacity=$dasd_size"
     fi
     echo "DiskDrive.$count.OperatingState=8"
     count=`expr $count + 1`
  done
  count=0
  for dasd_dir in /sys/block/sd*;
   do
     if [ "$dasd_dir" = "/sys/block/sd*" ]; then
       continue
     fi
     dasd_status=0
     dasd_devid=${dasd_dir#/sys/block/}
     echo "DiskDrive.$count.Name=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceID=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceType=2"
     if [ -f $dasd_dir/size ]; then
       dasd_size=`cat $dasd_dir/size`
       dasd_size=`expr $dasd_size / 2`
       echo "DiskDrive.$count.Capacity=$dasd_size"
     fi
     echo "DiskDrive.$count.OperatingState=8"
     count=`expr $count + 1`
  done
  return
}

####################################
# printDiskPartitions
####################################
printDiskPartitions()
{
  count=0
  cat /proc/partitions | grep 'dasd\|sd\|hd' | while read ONE TWO THREE FOUR FIVE
    do
      tempName=`echo $FOUR | grep '[0123456789]'`
      if [ "$tempName"  = "" ]; then
        continue
      fi
      echo "DiskPartition.$count.Name=/dev/$FOUR"
      echo "DiskPartition.$count.DeviceID=/dev/$FOUR"
      echo "DiskPartition.$count.NumberOfBlocks=$THREE"


      blockSize=`tune2fs -l /dev/$FOUR 2> /dev/null | grep 'Block size:' | cut -d: -f2 | tr -d ' '`
      if [ "$blockSize" = "" ]; then
         blockSize=`expr 2 / 2`
      fi
      echo "DiskPartition.$count.BlockSize=$blockSize"
      Capacity=`expr $blockSize \* $THREE`
      echo "DiskPartition.$count.Capacity=$Capacity"
      echo "DiskPartition.$count.PartitionType=2"

      echo "DiskPartition.$count.HealthState=1"
      count=`expr $count + 1`
    done
  return
}

####################################
# printLogicalVolumes
####################################
printLogicalVolumes()
{
  count=0
  cat /proc/partitions | grep 'dasd\|sd\|hd' | while read ONE TWO THREE FOUR FIVE
    do
      tempName=`echo $FOUR | grep '[0123456789]'`
      if [ "$tempName"  = "" ]; then
        continue
      fi
      echo "LogicalVolume.$count.Name=/dev/$FOUR"
      echo "LogicalVolume.$count.DeviceID=/dev/$FOUR"
      echo "LogicalVolume.$count.NumberOfBlocks=$THREE"
      echo "LogicalVolume.$count.Capacity=$THREE"
      echo "LogicalVolume.$count.BlockSize=1"
      echo "LogicalVolume.$count.HealthState=1"
      count=`expr $count + 1`
    done
  return
}

####################################
# printPhysicalVolumes
####################################
printPhysicalVolumes()
{
  count=0
    # we don't want to modify existing functionality for other linux based hypervisors such as KVM.
    # Get kernel release and if it is ESX specific, take different code path.
    ker_rel=`uname -r | grep 'ESX'`

    if [ "$ker_rel" = "" ]; then
        # Non ESX kernel. Original printPhysicalVolume code here.
        count=0
  cat /proc/partitions | grep 'sd' | while read ONE TWO THREE FOUR FIVE

    do
       LUNID=`multipath -l 2>/dev/null | grep $FOUR | cut -d " " -f3 | cut -d: -f4`

      if [ "$LUNID"  = "" ]; then
        continue
      fi

      echo "PhysicalVolume.$count.Name=/dev/$FOUR"
      echo "PhysicalVolume.$count.DeviceID=/dev/$FOUR"
      echo "PhysicalVolume.$count.NumberOfBlocks=$THREE"
      echo "PhysicalVolume.$count.Capacity=$THREE"
      echo "PhysicalVolume.$count.BlockSize=1"
      echo "PhysicalVolume.$count.HealthState=1"
      echo "PhysicalVolume.$count.LUNIdentifier=$LUNID"

      count=`expr $count + 1`

        done
    else
        # ESX specific code here.
        # Check if it is ESX 3.x or ESX 4.x
        esx4_ver=`vmware -v | grep 'ESX' | grep '4.*'`
        if [ "$esx4_ver" != "" ]; then
            # ESX 4.x specific functionality
            # LUNs are exposed as FC drives and are represented using NAA(Network Address Authority) addresses. So search for only devices having 'naa'.
            esxcfg-mpath -b | grep 'naa' | while read ONE TWO THREE FOUR FIVE
            do
             device_id=$ONE
             unique_id=${ONE#naa.} #remove the substring 'naa.' It would give unique id 60080e500017f0ea000006fb4d7f5267. set it to PhysicalVolume.ExternalUniqueID.

             # get LUN identifier from esxcfg-mpath command.
             lun_line=`esxcfg-mpath -b -d $device_id | grep 'LUN'`
             lun_id=${lun_line#*LUN:}
             lun_id=${lun_id%% *}  # truncate rest of the line after LUN:<lun number>

             # get device details from esxcfg-scsidevs command.
             device_line=`esxcfg-scsidevs -l -d $device_id | grep 'Console Device: '`
             dev_name=${device_line#*Console Device: }

             # get capacity information
             # it was observed that for some devices of smaller size, fdisk output contains MB but for large volumes it contains GB.
             # In order for code to succeed with all types of LUNs, we check both MB and GB.
             capInMB=`fdisk -l $dev_name 2>/dev/null | grep MB`
             capInGB=`fdisk -l $dev_name 2>/dev/null | grep GB`
             if [ "$capInMB" != "" ]; then
                capacity=${capInMB#*MB, }
             fi
             if [ "$capInGB" != "" ]; then
                capacity=${capInGB#*GB, }
             fi
             capacity=${capacity%% *}
             blkSize_line=`fdisk -l $dev_name 2>/dev/null | grep '*'`
             blk_size=${blkSize_line#*\* }
             blk_size=${blk_size%% *}
             num_blks=`expr $capacity / $blk_size`

             # print physical volume instance now.
             echo "PhysicalVolume.$count.ExternalUniqueID=$unique_id"
             echo "PhysicalVolume.$count.Name=$dev_name"
             echo "PhysicalVolume.$count.DeviceID=$dev_name"
             echo "PhysicalVolume.$count.LUNIdentifier=$lun_id"
             echo "PhysicalVolume.$count.Capacity=$capacity"
             echo "PhysicalVolume.$count.BlockSize=$blk_size"
             echo "PhysicalVolume.$count.NumberOfBlocks=$num_blks"

             count=`expr $count + 1`
            done
        else
            # ESX 3.x specific functionality
            echo "ESX 3 host"
        fi
    fi
    return
}

####################################
# printStorageVolumes
####################################
printStorageVolumes()
{

  count=0

  cat /proc/partitions | grep 'dm-' | while read ONE TWO THREE FOUR FIVE

    do
       UNQID=`multipath -l 2>/dev/null | grep $FOUR | cut -d " " -f2 | cut -c 2-34`

      if [ "$UNQID"  = "" ]; then
        continue
      fi

      echo "StorageVolume.$count.Name=/dev/$FOUR"
      echo "StorageVolume.$count.DeviceID=/dev/$FOUR"
      echo "StorageVolume.$count.NumberOfBlocks=$THREE"
      echo "StorageVolume.$count.Capacity=$THREE"
      echo "StorageVolume.$count.BlockSize=1"
      echo "StorageVolume.$count.HealthState=1"
      echo "StorageVolume.$count.ExternalUniqueIdentifier=$UNQID"

      count=`expr $count + 1`

    done

  return
}

####################################
# printFileSystems
####################################
printFileSystems()
{
  count=0
  df -l -T -P -B 1 | sed '1d' | while read ONE TWO THREE FOUR FIVE SIX SEVEN
    do
      echo "FileSystem.$count.Name=$ONE"
      echo "FileSystem.$count.Root=$SEVEN"
      echo "FileSystem.$count.Label=$SEVEN"
      echo "FileSystem.$count.HealthState=1"
      echo "FileSystem.$count.AvailableSpace=$FIVE"
      echo "FileSystem.$count.FileSystemSize=$THREE"
      fsType="0"
      if [ "$TWO" = "jfs" ]; then fsType="1"; fi
      if [ "$TWO" = "nfs" ]; then fsType="25"; fi
      if [ "$TWO" = "ufs" ]; then fsType="19"; fi
      if [ "$TWO" = "vfs" ]; then fsType="9"; fi
      if [ "$TWO" = "xfs" ]; then fsType="23"; fi
      if [ "$TWO" = "udf" ]; then fsType="16"; fi
      if [ "$TWO" = "ext2" ]; then fsType="12"; fi
      if [ "$TWO" = "ext3" ]; then fsType="13"; fi
      if [ "$TWO" = "jfs2" ]; then fsType="3"; fi
      if [ "$TWO" = "ntfs" ]; then fsType="6"; fi
      if [ "$TWO" = "swap" ]; then fsType="22"; fi
      if [ "$TWO" = "fat16" ]; then fsType="8"; fi
      if [ "$TWO" = "fat32" ]; then fsType="7"; fi
      if [ "$TWO" = "namefs" ]; then fsType="26"; fi
      if [ "$TWO" = "reiserfs" ]; then fsType="14"; fi
      if [ "$TWO" = "linuxlvm" ]; then fsType="24"; fi
      echo "FileSystem.$count.FileSystemType=$fsType"
      count=`expr $count + 1`
    done
  return
}

fcCount=0
swCount=0

####################################
# printFibreChannel
####################################
printFibreChannel()
{
  printQLogicFibreChannel
  printEmulexFibreChannel
  printLegacyQLogicFibreChannel
}

####################################
# printQLogicFibreChannel
####################################
printQLogicFibreChannel()
{
  for fc_dir in /sys/class/scsi_host/*;
   do
     fc_subdir=${fc_dir#/sys/class/scsi_host/}
     fc_dir2=/sys/class/fc_host/$fc_subdir
     ########################
     # QLogic - If the Model starts with QL then it is QLogic
     ########################
     if [ -f $fc_dir/model_name ] && [ -f $fc_dir2/port_name ]; then
       model=`cat $fc_dir/model_name`

       if [ ${model#QL} != $model  -o  ${model#QM} != $model ]; then
         portWWN=`cat $fc_dir2/port_name | tr "[:lower:]" "[:upper:]"`
         portWWN=${portWWN#0X}       
         portId=00000$fcCount
         if [ -f $fc_dir2/port_id ]; then
           portId=`cat $fc_dir2/port_id`
           portId=${portId#0x}
         fi
         nodeWWN=""
         if [ -f $fc_dir2/node_name ]; then
           nodeWWN=`cat $fc_dir2/node_name`
           nodeWWN=${nodeWWN#0x}
         fi
         echo "HBAAdapter.$fcCount.Name=$portWWN"
         echo "FCPort.$fcCount.Name=$portWWN"
         echo "FCPort.$fcCount.DeviceID=${portWWN}"
         echo "FCPort.$fcCount.Model=$model"
         echo "FCPort.$fcCount.LinkTechnology=4"
         echo "FCPort.$fcCount.PermanentAddress=$portWWN"
         echo "SCSIPort.$fcCount.Name=$portWWN"
         echo "SCSIPort.$fcCount.ConnectionType=1"
         echo "SCSIPort.$fcCount.Role=1"
         if [ -f $fc_dir2/fabric_name ]; then
           fabricName=`cat $fc_dir2/fabric_name`
           fabricName=${fabricName#0x}
           echo "FCPort.$fcCount.FabricName=$fabricName"
         fi
         if [ -f $fc_dir2/port_state ]; then
           portState=0
           if [ `cat $fc_dir2/port_state` = "Online" ]; then portState=8
           else portState=5
           fi
           echo "FCPort.$fcCount.OperatingState=$portState"
           echo "SCSIPort.$fcCount.OperatingState=$portState"
         fi
         if [ -f $fc_dir2/speed ]; then
           speedStr=`cat $fc_dir2/speed`
           if [ "${speedStr% Gbit}" != "$speedStr" ]; then
             speed=${speedStr% Gbit}000000000
             echo "FCPort.$fcCount.Speed=$speed"
           else
             if [ "${speedStr% Mbit}" != "$speedStr" ]; then
               speed=${speedStr% Mbit}000000
               echo "FCPort.$fcCount.Speed=$speed"
             fi
           fi
         fi
         echo "HBACard.$fcCount.Name=$model"
         echo "HBACard.$fcCount.Model=$model"
         echo "HBACard.$fcCount.Manufacturer=QLogic Corporation"
         serialNum=""
         if [ -f $fc_dir/serial_num ]; then
           serialNum=`cat $fc_dir/serial_num`
         fi
         if [ "$serialNum" = "" ]; then
           echo "HBACard.$fcCount.Tag=$portId"
           echo "HBAAdapter.$fcCount.DeviceID=$portId"
         else
           echo "HBACard.$fcCount.SerialNumber=$serialNum"
           echo "HBACard.$fcCount.Tag=$serialNum"
           echo "HBAAdapter.$fcCount.DeviceID=$serialNum"
         fi
         firmwareVersion=""
         if [ -f $fc_dir/optrom_fw_version ]; then
           firmwareVersion=`cat $fc_dir/optrom_fw_version`
           firmwareVersion=${firmwareVersion% *}
         else
           if [ -f $fc_dir/fw_version ]; then
             firmwareVersion=`cat $fc_dir/fw_version`
             firmwareVersion=${firmwareVersion% *}
           fi
         fi
         if [ "$firmwareVersion" != "" ]; then
           echo "HBASoftware.$swCount.Name=QLogic HBA Firmware"
           echo "HBASoftware.$swCount.Vendor=QLogic Corporation"
           echo "HBASoftware.$swCount.Version=$firmwareVersion"
           echo "HBASoftware.$swCount.Category=7"
           echo "HBASoftware.$swCount.SoftwareID=$model"
           echo "HBASoftware.$swCount.SubCategory=HBA"
           echo "HBASoftware.$swCount.InstalledLocation=System0"
           swCount=`expr $swCount + 1`
         fi
         if [ -f $fc_dir/driver_version ]; then
           driverVersion=`cat $fc_dir/driver_version`
           echo "HBASoftware.$swCount.Name=QLogic HBA Driver"
           echo "HBASoftware.$swCount.Vendor=QLogic Corporation"
           echo "HBASoftware.$swCount.Version=$driverVersion"
           echo "HBASoftware.$swCount.Category=9"
           echo "HBASoftware.$swCount.SoftwareID=$model"
           echo "HBASoftware.$swCount.SubCategory=HBA"
           echo "HBASoftware.$swCount.InstalledLocation=System0"
           swCount=`expr $swCount + 1`
         fi
         if [ -f $fc_dir/optrom_bios_version ]; then
           biosVersion=`cat $fc_dir/optrom_bios_version`
           echo "HBASoftware.$swCount.Name=QLogic HBA BIOS"
           echo "HBASoftware.$swCount.Vendor=QLogic Corporation"
           echo "HBASoftware.$swCount.Version=$biosVersion"
           echo "HBASoftware.$swCount.Category=8"
           echo "HBASoftware.$swCount.SoftwareID=$model"
           echo "HBASoftware.$swCount.SubCategory=HBA"
           echo "HBASoftware.$swCount.InstalledLocation=System0"
           swCount=`expr $swCount + 1`
         fi
         echo "HBACardRealizes.$fcCount.SourceId=$fcCount"
         echo "HBACardRealizes.$fcCount.TargetId=$fcCount"
         echo "HBAControlledBy.$fcCount.SourceId=$fcCount"
         echo "HBAControlledBy.$fcCount.TargetId=$fcCount"
         echo "HBAAccessedVia.$fcCount.SourceId=$fcCount"
         echo "HBAAccessedVia.$fcCount.TargetId=$fcCount"
         fcCount=`expr $fcCount + 1`
       fi
     fi
  done
  return
}

####################################
# printEmulexFibreChannel
####################################
printEmulexFibreChannel()
{
  for fc_dir in /sys/class/scsi_host/*;
   do
     fc_subdir=${fc_dir#/sys/class/scsi_host/}
     fc_dir2=/sys/class/fc_host/$fc_subdir
     ########################
     # Emulex - If the Driver File contains Emulex then it is Emulex
     ########################
     if [ -f $fc_dir/lpfc_drvr_version ]; then
       driver=`cat $fc_dir/lpfc_drvr_version`
       if [ "${driver#Emulex}" != "$driver" ] && [ -f $fc_dir2/port_name ] && [ -f $fc_dir/modelname ]; then
         model=`cat $fc_dir/modelname`
         portWWN=`cat $fc_dir2/port_name | tr "[:lower:]" "[:upper:]"`
         portWWN=${portWWN#0X}
         portId=00000$fcCount
         if [ -f $fc_dir2/port_id ]; then
           portId=`cat $fc_dir2/port_id`
           portId=${portId#0x}
         fi
         nodeWWN=""
         if [ -f $fc_dir2/node_name ]; then
           nodeWWN=`cat $fc_dir2/node_name`
           nodeWWN=${nodeWWN#0x}
         fi
         echo "HBAAdapter.$fcCount.Name=$portId"
         echo "FCPort.$fcCount.Name=$portWWN"
         echo "FCPort.$fcCount.DeviceID=$portWWN"
         echo "FCPort.$fcCount.Model=$model"
         echo "FCPort.$fcCount.LinkTechnology=4"
         echo "FCPort.$fcCount.PermanentAddress=$portWWN"
         if [ -f $fc_dir2/fabric_name ]; then
           fabricName=`cat $fc_dir2/fabric_name`
           fabricName=${fabricName#0x}
           echo "FCPort.$fcCount.FabricName=$fabricName"
         fi
         if [ -f $fc_dir2/port_state ]; then
           portState=0
           if [ `cat $fc_dir2/port_state` = "Online" ]; then portState=8
           else portState=5
           fi
           echo "FCPort.$fcCount.OperatingState=$portState"
         fi
         if [ -f $fc_dir2/speed ]; then
           speedStr=`cat $fc_dir2/speed`
           if [ "${speedStr% Gbit}" != "$speedStr" ]; then
             speed=${speedStr% Gbit}000000000
             echo "FCPort.$fcCount.Speed=$speed"
           else
             if [ "${speedStr% Mbit}" != "$speedStr" ]; then
               speed=${speedStr% Mbit}000000
               echo "FCPort.$fcCount.Speed=$speed"
             fi
           fi
         fi
         echo "HBACard.$fcCount.Name=$model"
         echo "HBACard.$fcCount.Model=$model"
         echo "HBACard.$fcCount.Manufacturer=Emulex"
         serialNum=""
         if [ -f $fc_dir/serialnum ]; then
           serialNum=`cat $fc_dir/serialnum`
         fi

         if [ "$serialNum" = "" ]; then
           echo "HBACard.$fcCount.Tag=$portId"
           echo "HBAAdapter.$fcCount.DeviceID=$portId"
         else
           echo "HBACard.$fcCount.SerialNumber=$serialNum"
           echo "HBACard.$fcCount.Tag=$serialNum"
           echo "HBAAdapter.$fcCount.DeviceID=$serialNum"
         fi

         if [ -f $fc_dir/fwrev ]; then
           firmwareVersion=`cat $fc_dir/fwrev`
           firmwareVersion=${firmwareVersion%% *}
           echo "HBASoftware.$swCount.Name=Emulex HBA Firmware"
           echo "HBASoftware.$swCount.Vendor=Emulex"
           echo "HBASoftware.$swCount.Version=$firmwareVersion"
           echo "HBASoftware.$swCount.Category=7"
           echo "HBASoftware.$swCount.SoftwareID=$model"
           echo "HBASoftware.$swCount.SubCategory=HBA"
           echo "HBASoftware.$swCount.InstalledLocation=System0"
           swCount=`expr $swCount + 1`
         fi
         if [ -f $fc_dir/lpfc_drvr_version ]; then
           driverVersion=`cat $fc_dir/lpfc_drvr_version`
           driverVersion=${driverVersion#*driver }
           echo "HBASoftware.$swCount.Name=Emulex HBA driver"
           echo "HBASoftware.$swCount.Vendor=Emulex"
           echo "HBASoftware.$swCount.Version=$driverVersion"
           echo "HBASoftware.$swCount.Category=9"
           echo "HBASoftware.$swCount.SoftwareID=$model"
           echo "HBASoftware.$swCount.SubCategory=HBA"
           echo "HBASoftware.$swCount.InstalledLocation=System0"
           swCount=`expr $swCount + 1`
         fi
         echo "HBACardRealizes.$fcCount.SourceId=$fcCount"
         echo "HBACardRealizes.$fcCount.TargetId=$fcCount"
         echo "HBAControlledBy.$fcCount.SourceId=$fcCount"
         echo "HBAControlledBy.$fcCount.TargetId=$fcCount"
         fcCount=`expr $fcCount + 1`
       fi
     fi
  done
  return
}

####################################
# printLegacyQLogicFibreChannel
####################################
printLegacyQLogicFibreChannel()
{
  for fc_file in /proc/scsi/ql*/*;
   do
    if [ -f $fc_file ]; then
     full_file=`cat $fc_file`
     first_line=${full_file%%:*}
     sfw_line=`cat $fc_file | grep 'Flash FW version'`
     drv_line=`cat $fc_file | grep 'Driver version'`
     serial_line=`cat $fc_file | grep 'Serial'`
     bios_line=`cat $fc_file | grep 'BIOS'`
     nodewwn_line=`cat $fc_file | grep 'adapter-node='`
     portwwn_line=`cat $fc_file | grep 'adapter-port=' | tr "[:lower:]" "[:upper:]"`
     state_line=`cat $fc_file | grep 'loop state'`

     if [ "${first_line##* QL}" != "$first_line" ]; then
        model=${first_line##* QL}
        model=QL${model%:}
     elif [ "${first_line##* QM}" != "$first_line" ]; then
        model=${first_line##* QM}
        model=QM${model%:}
     fi

    if [ ${model#QL} != $model  -o  ${model#QM} != $model ]; then

     portId=00000${fc_file#/proc/scsi/ql*/}
     firmwareVersion=${sfw_line#*Flash FW version }
     firmwareVersion=${firmwareVersion%% *}
     driverVersion=${drv_line#*Driver version }
     driverVersion=${driverVersion%% *}
     biosVersion=${bios_line#*BIOS version }
     biosVersion=${biosVersion%% *}
     serialNum=${serial_line#*Serial# }
     serialNum=${serialNum%% *}
     nodeWWN=${nodewwn_line#*adapter-node=}
     nodeWWN=${nodeWWN%%;*}
     portWWN=${portwwn_line#*ADAPTER-PORT=}
     portWWN=${portWWN%%;*}
     # For ESX 4.x we found that FCPort WWPNs are having : which is incorrect. 
     # Following code within 'if' removes information after : if present, and prints only WWPN addresses.
     if [ ${portWWN#*:} != "" ]; then
       # Remove : entries from FCPort WWPN address.
       portWWN=${portWWN%%:*}
       nodeWWN=${nodeWWN%%:*}
     fi
     portState=5
     if [ "${state_line#*READY}" != "$state_line" ]; then
       portState=8
     fi

     if [ "$portWWN" != "" ]; then
       echo "HBAAdapter.$fcCount.Name=$portWWN"
       echo "FCPort.$fcCount.Name=$portWWN"
       echo "FCPort.$fcCount.DeviceID=$portWWN"
       echo "FCPort.$fcCount.Model=$model"
       echo "FCPort.$fcCount.LinkTechnology=4"
       echo "FCPort.$fcCount.PermanentAddress=$portWWN"
       echo "FCPort.$fcCount.OperatingState=$portState"
       echo "SCSIPort.$fcCount.Name=$portWWN"
       echo "SCSIPort.$fcCount.ConnectionType=1"
       echo "SCSIPort.$fcCount.Role=1"
       echo "SCSIPort.$fcCount.OperatingState=$portState"
       echo "HBACard.$fcCount.Name=$model"
         if [ "$serialNum" = "" ]; then
           if [ -f /opt/ibm/icc/bin/cimcli ]; then
             serial_line=`/opt/ibm/icc/bin/cimcli -n root/qlogic_cmpi ei QLogicFCHBA_PhysicalPackage | grep 'SerialNumber'`
             serialNum=${serial_line#*SerialNumber = \"}
             serialNum=${serialNum%%\"*}
           fi
         fi
         if [ "$serialNum" = "" ]; then
           echo "HBACard.$fcCount.Tag=$portId"
           echo "HBAAdapter.$fcCount.DeviceID=$portId"
         else
           echo "HBACard.$fcCount.Tag=$serialNum"
           echo "HBACard.$fcCount.SerialNumber=$serialNum"
           echo "HBAAdapter.$fcCount.DeviceID=$serialNum"
         fi

       echo "HBACard.$fcCount.Model=$model"
       echo "HBACard.$fcCount.Manufacturer=QLogic Corporation"

       echo "HBASoftware.$swCount.Name=QLogic HBA Firmware"
       echo "HBASoftware.$swCount.Vendor=QLogic Corporation"
       echo "HBASoftware.$swCount.Version=$firmwareVersion"
       echo "HBASoftware.$swCount.Category=7"
       echo "HBASoftware.$swCount.SoftwareID=$model"
       echo "HBASoftware.$swCount.SubCategory=HBA"
       echo "HBASoftware.$swCount.InstalledLocation=System0"
       swCount=`expr $swCount + 1`
       echo "HBASoftware.$swCount.Name=QLogic HBA Driver"
       echo "HBASoftware.$swCount.Vendor=QLogic Corporation"
       echo "HBASoftware.$swCount.Version=$driverVersion"
       echo "HBASoftware.$swCount.Category=9"
       echo "HBASoftware.$swCount.SoftwareID=$model"
       echo "HBASoftware.$swCount.SubCategory=HBA"
       echo "HBASoftware.$swCount.InstalledLocation=System0"
       swCount=`expr $swCount + 1`
       echo "HBASoftware.$swCount.Name=QLogic HBA BIOS"
       echo "HBASoftware.$swCount.Vendor=QLogic Corporation"
       echo "HBASoftware.$swCount.Version=$biosVersion"
       echo "HBASoftware.$swCount.Category=8"
       echo "HBASoftware.$swCount.SoftwareID=$model"
       echo "HBASoftware.$swCount.SubCategory=HBA"
       echo "HBASoftware.$swCount.InstalledLocation=System0"
       swCount=`expr $swCount + 1`
       echo "HBACardRealizes.$fcCount.SourceId=$fcCount"
       echo "HBACardRealizes.$fcCount.TargetId=$fcCount"
       echo "HBAControlledBy.$fcCount.SourceId=$fcCount"
       echo "HBAControlledBy.$fcCount.TargetId=$fcCount"
       echo "HBAAccessedVia.$fcCount.SourceId=$fcCount"
       echo "HBAAccessedVia.$fcCount.TargetId=$fcCount"
       fcCount=`expr $fcCount + 1`
     fi
     fi
    fi
  done
  return
}

####################################
# printNICs
####################################
printNICs()
{
  count=0
  lancount=0
  devicelist=`ifconfig | grep "Link encap" | sed /"Local Loopback"/d | cut -d ' ' -f 1`

    if [ -f /opt/ibm/platform/version.lv1 ]; then
      version=`cat /opt/ibm/platform/version.lv1 | grep "version=" | cut -d = -f 2 | sed 's/\.//' | cut -d . -f 1-2`
    else
      if [ -f /opt/ibm/director/version.key ]; then
        version=`cat /opt/ibm/director/version.key | grep "version=" | cut -d = -f 2 | sed 's/\.//' | cut -d . -f 1-2`
      fi
    fi
    longversion=`echo "$version" | grep "\."`
    if [ "$longversion" != "" ]; then
      version=`echo "$version" | sed 's/\.//'`
    else
      version=`echo $version"0"`
    fi 
    version=`echo $version | cut -b1-3`
#    echo "version = $version"
  for netdevice in $devicelist
   do
    laslave=`ifconfig $netdevice | grep "SLAVE"`
    lamaster=`ifconfig $netdevice | grep "MASTER"`
    ipaddress=`ifconfig $netdevice | grep "inet addr" | tr -s ' ' ',' | cut -d , -f 3 | sed 's/addr://'`
    ipv6=`ifconfig $netdevice | grep "inet6 addr" | tr -s ' ' ',' | cut -d , -f 4 | sed 's/addr://'`
    subnetmask=`ifconfig $netdevice | grep "inet addr" | tr -s ' ' ',' | cut -d , -f 5 | sed 's/Mask://'`
    netdevice_stripped=`echo "$netdevice" | cut -d : -f 1`
    gateway=`route -n | grep "$netdevice_stripped" | grep "UG" | tr -s ' ' ',' | cut -d , -f 2`
    macaddrLine=`ifconfig $netdevice | grep "HWaddr"`
    macaddress=${macaddrLine#*HWaddr }
    macaddress=`echo $macaddress | sed s/://g`
    # remove the dup entry if it's there
    macaddress=`echo ${macaddress%% *}`

   if [ "$lamaster" != "" ] && [ $version -gt 620 ]; then
      continue
   fi
    if [ "$ipv6" != "" ]; then
      for ip6info in $ipv6
      do
        prefixlen=${ip6info#*/}
        ip6address=${ip6info%/*}   
        echo "CSIPProtocolEndpoint.$count.Name=$ip6address"
        echo "CSIPProtocolEndpoint.$count.Gateway=$gateway"
        echo "CSIPProtocolEndpoint.$count.IPv6Address=$ip6address"
        echo "CSIPProtocolEndpoint.$count.HostType=CS"
        echo "CSIPProtocolEndpoint.$count.PrefixLength=$prefixlen" 
        echo "OSIPProtocolEndpoint.$count.Name=$ip6address"
        echo "OSIPProtocolEndpoint.$count.Gateway=$gateway"
        echo "OSIPProtocolEndpoint.$count.PrefixLength=$prefixlen"
        echo "OSIPProtocolEndpoint.$count.IPv6Address=$ip6address"
        echo "OSIPProtocolEndpoint.$count.HostType=OS"
        echo "CSBindsTo.$count.SourceId=$count"
        echo "CSBindsTo.$count.TargetId=$lancount"
        echo "OSBindsTo.$count.SourceId=$count"
        echo "OSBindsTo.$count.TargetId=$lancount"
        count=`expr $count + 1`
      done
    fi
    if [ "$ipaddress" != "" ]; then
      echo "CSIPProtocolEndpoint.$count.Name=$ipaddress"
      echo "CSIPProtocolEndpoint.$count.Gateway=$gateway"
      echo "CSIPProtocolEndpoint.$count.SubnetMask=$subnetmask"
      echo "CSIPProtocolEndpoint.$count.IPv4Address=$ipaddress"
      echo "CSIPProtocolEndpoint.$count.HostType=CS"
      echo "OSIPProtocolEndpoint.$count.Name=$ipaddress"
      echo "OSIPProtocolEndpoint.$count.Gateway=$gateway"
      echo "OSIPProtocolEndpoint.$count.SubnetMask=$subnetmask"
      echo "OSIPProtocolEndpoint.$count.IPv4Address=$ipaddress"
      echo "OSIPProtocolEndpoint.$count.HostType=OS"
      echo "CSBindsTo.$count.SourceId=$count"
      echo "CSBindsTo.$count.TargetId=$lancount"
      echo "OSBindsTo.$count.SourceId=$count"
      echo "OSBindsTo.$count.TargetId=$lancount"
      count=`expr $count + 1`
    fi
    if [ "$ipaddress" != "" ] || [ "$ip6info" != "" ]; then
      echo "CSLANEndpoint.$lancount.Name=$macaddress"
      echo "CSLANEndpoint.$lancount.DisplayName=$netdevice_stripped"
      echo "CSLANEndpoint.$lancount.DeviceName=$netdevice_stripped"
      echo "CSLANEndpoint.$lancount.MACAddress=$macaddress"
      echo "CSLANEndpoint.$lancount.HostType=CS"
      echo "OSLANEndpoint.$lancount.Name=$macaddress"
      echo "OSLANEndpoint.$lancount.DisplayName=$netdevice_stripped"
      echo "OSLANEndpoint.$lancount.DeviceName=$netdevice_stripped"
      echo "OSLANEndpoint.$lancount.MACAddress=$macaddress"
      echo "OSLANEndpoint.$lancount.HostType=OS"
      lancount=`expr $lancount + 1`
    fi
  done
  return
}

####################################
# printMetaInfo
####################################
printMetaInfo()
{
# --Chassis-- #
  echo "Resource.Chassis.ClassName=Chassis"
  echo "Resource.Chassis.Defer=true"
  echo "Resource.Chassis.Keys=Tag"
  echo "Relationship.ChassisCS.ClassName=ComputerSystemContainsPhysicalElement"
  echo "Relationship.ChassisCS.Defer=true"
  echo "Relationship.ChassisCS.Implicit=true"
  echo "Relationship.ChassisCS.SourceClass=Server"
  echo "Relationship.ChassisCS.TargetClass=Chassis"
# --Processor-- #
  echo "Resource.Processor.ClassName=Processor"
  echo "Resource.Processor.Defer=true"
  echo "Resource.Processor.Keys=DeviceID"
  echo "Relationship.ProcessorCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.ProcessorCS.Defer=true"
  echo "Relationship.ProcessorCS.Implicit=true"
  echo "Relationship.ProcessorCS.SourceClass=Server"
  echo "Relationship.ProcessorCS.TargetClass=Processor"
# --PhysicalMemory-- #
  echo "Resource.PhysicalMemory.ClassName=PhysicalMemory"
  echo "Resource.PhysicalMemory.Defer=true"
  echo "Resource.PhysicalMemory.Keys=Tag"
  echo "Relationship.PhysicalMemoryCS.ClassName=ComputerSystemContainsPhysicalElement"
  echo "Relationship.PhysicalMemoryCS.Defer=true"
  echo "Relationship.PhysicalMemoryCS.Implicit=true"
  echo "Relationship.PhysicalMemoryCS.SourceClass=Server"
  echo "Relationship.PhysicalMemoryCS.TargetClass=PhysicalMemory"
# --DiskDrive-- #
  echo "Resource.DiskDrive.ClassName=DiskDrive"
  echo "Resource.DiskDrive.Defer=true"
  echo "Resource.DiskDrive.Keys=DeviceID"
  echo "Relationship.DiskDriveCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.DiskDriveCS.Defer=true"
  echo "Relationship.DiskDriveCS.Implicit=true"
  echo "Relationship.DiskDriveCS.SourceClass=Server"
  echo "Relationship.DiskDriveCS.TargetClass=DiskDrive"
# --DiskPartition-- #
  echo "Resource.DiskPartition.ClassName=DiskPartition"
  echo "Resource.DiskPartition.Defer=true"
  echo "Resource.DiskPartition.Keys=DeviceID"
  echo "Relationship.DiskPartitionCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.DiskPartitionCS.Defer=true"
  echo "Relationship.DiskPartitionCS.Implicit=true"
  echo "Relationship.DiskPartitionCS.SourceClass=Server"
  echo "Relationship.DiskPartitionCS.TargetClass=DiskPartition"
# --LogicalVolume-- #
  echo "Resource.LogicalVolume.ClassName=LogicalVolume"
  echo "Resource.LogicalVolume.Defer=true"
  echo "Resource.LogicalVolume.Keys=DeviceID"
  echo "Relationship.LogicalVolumeCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.LogicalVolumeCS.Defer=true"
  echo "Relationship.LogicalVolumeCS.Implicit=true"
  echo "Relationship.LogicalVolumeCS.SourceClass=Server"
  echo "Relationship.LogicalVolumeCS.TargetClass=LogicalVolume"
# --PhysicalVolume-- #
  echo "Resource.PhysicalVolume.ClassName=PhysicalVolume"
  echo "Resource.PhysicalVolume.Defer=true"
  echo "Resource.PhysicalVolume.Keys=DeviceID"
  echo "Relationship.PhysicalVolumeCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.PhysicalVolumeCS.Defer=true"
  echo "Relationship.PhysicalVolumeCS.Implicit=true"
  echo "Relationship.PhysicalVolumeCS.SourceClass=Server"
  echo "Relationship.PhysicalVolumeCS.TargetClass=PhysicalVolume"
# --StorageVolume-- #
  echo "Resource.StorageVolume.ClassName=StorageVolume"
  echo "Resource.StorageVolume.Defer=true"
  echo "Resource.StorageVolume.Keys=DeviceID"
  echo "Relationship.StorageVolumeCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.StorageVolumeCS.Defer=true"
  echo "Relationship.StorageVolumeCS.Implicit=true"
  echo "Relationship.StorageVolumeCS.SourceClass=Server"
  echo "Relationship.StorageVolumeCS.TargetClass=StorageVolume"
# --FileSystem-- #
  echo "Resource.FileSystem.ClassName=FileSystem"
  echo "Resource.FileSystem.Keys=Name"
  echo "Relationship.FileSystemCS.ClassName=ComputerSystemContainsFileSystem"
  echo "Relationship.FileSystemCS.Implicit=true"
  echo "Relationship.FileSystemCS.SourceClass=Server"
  echo "Relationship.FileSystemCS.TargetClass=FileSystem"
# --FibreChannel-- #
  echo "Resource.FCPort.ClassName=FCPort"
  echo "Resource.FCPort.Keys=DeviceID"
  echo "Resource.HBAAdapter.ClassName=PortController"
  echo "Resource.HBAAdapter.Keys=DeviceID"
  echo "Resource.HBACard.ClassName=Card"
  echo "Resource.HBACard.Keys=Tag"
  echo "Resource.HBASoftware.ClassName=SoftwareInstallation"
  echo "Resource.HBASoftware.Defer=false"
  echo "Resource.HBASoftware.Keys=Name,Version"
  echo "Resource.SCSIPort.ClassName=SCSIProtocolEndpoint"
  echo "Resource.SCSIPort.Keys=Name"
  echo "Relationship.FCPortCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.FCPortCS.Implicit=true"
  echo "Relationship.FCPortCS.SourceClass=Server"
  echo "Relationship.FCPortCS.TargetClass=FCPort"
  echo "Relationship.SCSIPortCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.SCSIPortCS.Implicit=true"
  echo "Relationship.SCSIPortCS.SourceClass=Server"
  echo "Relationship.SCSIPortCS.TargetClass=SCSIProtocolEndpoint"
  echo "Relationship.HBAAdapterCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.HBAAdapterCS.Implicit=true"
  echo "Relationship.HBAAdapterCS.SourceClass=Server"
  echo "Relationship.HBAAdapterCS.TargetClass=PortController"
  echo "Relationship.HBAAdapterCS.TargetAlias=HBAAdapter"
  echo "Relationship.HBACardCS.ClassName=ComputerSystemContainsPhysicalElement"
  echo "Relationship.HBACardCS.Implicit=true"
  echo "Relationship.HBACardCS.SourceClass=Server"
  echo "Relationship.HBACardCS.TargetClass=Card"
  echo "Relationship.HBACardCS.TargetAlias=HBACard"
  echo "Relationship.HBASoftwareCS.ClassName=SoftwareResourceInstalledOnComputerSystem"
  echo "Relationship.HBASoftwareCS.Implicit=true"
  echo "Relationship.HBASoftwareCS.SourceClass=SoftwareInstallation"
  echo "Relationship.HBASoftwareCS.SourceAlias=HBASoftware"
  echo "Relationship.HBASoftwareCS.TargetClass=Server"
  echo "Relationship.HBACardRealizes.ClassName=PhysicalElementRealizesLogicalDevice"
  echo "Relationship.HBACardRealizes.SourceClass=Card"
  echo "Relationship.HBACardRealizes.SourceAlias=HBACard"
  echo "Relationship.HBACardRealizes.TargetClass=PortController"
  echo "Relationship.HBACardRealizes.TargetAlias=HBAAdapter"
  echo "Relationship.HBAControlledBy.ClassName=LogicalDeviceControlledByController"
  echo "Relationship.HBAControlledBy.SourceClass=FCPort"
  echo "Relationship.HBAControlledBy.TargetClass=PortController"
  echo "Relationship.HBAControlledBy.TargetAlias=HBAAdapter"
  echo "Relationship.HBAAccessedVia.ClassName=LogicalDeviceAccessedViaServiceAccessPoint"
  echo "Relationship.HBAAccessedVia.SourceClass=FCPort"
  echo "Relationship.HBAAccessedVia.TargetClass=SCSIProtocolEndpoint"
  echo "Relationship.HBAAccessedVia.TargetAlias=SCSIPort"
# --NICs-- #
  echo "Resource.CSLANEndpoint.ClassName=LANEndpoint"
  echo "Resource.CSLANEndpoint.Keys=Name,HostType"
  echo "Resource.OSLANEndpoint.ClassName=LANEndpoint"
  echo "Resource.OSLANEndpoint.Keys=Name,HostType"
  echo "Resource.CSIPProtocolEndpoint.ClassName=IPProtocolEndpoint"
  echo "Resource.CSIPProtocolEndpoint.Keys=Name,HostType"
  echo "Resource.OSIPProtocolEndpoint.ClassName=IPProtocolEndpoint"
  echo "Resource.OSIPProtocolEndpoint.Keys=Name,HostType"
  echo "Relationship.LANEndpointCS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.LANEndpointCS.Implicit=true"
  echo "Relationship.LANEndpointCS.SourceClass=Server"
  echo "Relationship.LANEndpointCS.TargetClass=LANEndpoint"
  echo "Relationship.LANEndpointCS.TargetAlias=CSLANEndpoint"
  echo "Relationship.IPProtocolEndpointCS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointCS.Implicit=true"
  echo "Relationship.IPProtocolEndpointCS.SourceClass=Server"
  echo "Relationship.IPProtocolEndpointCS.TargetClass=IPProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointCS.TargetAlias=CSIPProtocolEndpoint"
  echo "Relationship.LANEndpointOS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.LANEndpointOS.Implicit=true"
  echo "Relationship.LANEndpointOS.SourceClass=OperatingSystem"
  echo "Relationship.LANEndpointOS.TargetClass=LANEndpoint"
  echo "Relationship.LANEndpointOS.TargetAlias=OSLANEndpoint"
  echo "Relationship.IPProtocolEndpointOS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointOS.Implicit=true"
  echo "Relationship.IPProtocolEndpointOS.SourceClass=OperatingSystem"
  echo "Relationship.IPProtocolEndpointOS.TargetClass=IPProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointOS.TargetAlias=OSIPProtocolEndpoint"
  echo "Relationship.CSBindsTo.ClassName=ProtocolEndpointBindsToProtocolEndpoint"
  echo "Relationship.CSBindsTo.SourceClass=IPProtocolEndpoint"
  echo "Relationship.CSBindsTo.SourceAlias=CSIPProtocolEndpoint"
  echo "Relationship.CSBindsTo.TargetClass=LANEndpoint"
  echo "Relationship.CSBindsTo.TargetAlias=CSLANEndpoint"
  echo "Relationship.OSBindsTo.ClassName=ProtocolEndpointBindsToProtocolEndpoint"
  echo "Relationship.OSBindsTo.SourceClass=IPProtocolEndpoint"
  echo "Relationship.OSBindsTo.SourceAlias=OSIPProtocolEndpoint"
  echo "Relationship.OSBindsTo.TargetClass=LANEndpoint"
  echo "Relationship.OSBindsTo.TargetAlias=OSLANEndpoint"
  return
}

####################################
# main(String[] args)
####################################
  os_arch=`uname -m`

  PATH=$PATH:/usr/local/sbin:/sbin:/bin:/usr/sbin

  if [ "${os_arch#s390}" = "$os_arch" ] && [ "${os_arch#ppc}" = "$os_arch" ]; then
    printMetaInfo
    printChassis
    printProcessors
    printPhysicalMemory
    printDiskDrives
    printDiskPartitions
#    printLogicalVolumes
    printPhysicalVolumes
    printFileSystems
    printFibreChannel
    printNICs
    printStorageVolumes
  fi
