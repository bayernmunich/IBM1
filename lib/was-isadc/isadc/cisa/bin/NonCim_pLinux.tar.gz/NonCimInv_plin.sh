#!/bin/sh
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2009, 2011 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplicate or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

globalstrval=""
yIndex=0
pIndex=0
dIndex=0
portIndex=0
physicalFrameindex=0
physicalPackageindex=0
cardDataWritten=0
portDataWritten=0
physicalFrameDataWritten=0
physicalPackageDataWritten=0
isLocationCodeDuplicate=false
searchLocationCode=""
matchedLine=""
relationshipIndex=0
memoryIndex=0
memoryFound=0
memoryDatawritten=0
rcindex=0

####################################
# printPhysicalFrame
####################################
printPhysicalFrame()
{
  machmodel=`cat /proc/device-tree/model`
  serialnum=`cat /proc/device-tree/system-id`
  machmodel=${machmodel#*,}
  serialnum=${serialnum#*,}
  machmodel=`echo $machmodel | sed s/-//`
  if [ "${machmodel#*-}" != "$machmodel" ]; then
    machmodel=${machmodel%-*}${machmodel#*-}
  fi
  if [ "${#serialnum}" = "9" ]; then
    serialnum=${serialnum:2:7}
  fi
  model=${machmodel:4:3}
  machtype=${machmodel:0:4}

  echo "PhysicalFrame.0.Name=IBM,$machtype-$model-$serialnum"
  echo "PhysicalFrame.0.Tag=U$machtype.$model.$serialnum"
  echo "PhysicalFrame.0.Manufacturer=IBM"
  echo "PhysicalFrame.0.Model=$model"
  echo "PhysicalFrame.0.VendorType=$machtype"
  echo "PhysicalFrame.0.SerialNumber=$serialnum"
  echo "PhysicalFrame.0.PackageType=3"
  return
}

####################################
# printProcessors
####################################
printProcessors()
{
  count=0
  for proc_dir in /proc/device-tree/cpus/Power*;
   do
     width=32
     name=CPU$count
     cpuid=${proc_dir#*@}
     if [ -f $proc_dir/name ]; then
       name=`cat $proc_dir/name`
     fi
     if [ -f $proc_dir/64-bit ]; then
       width=64
     fi

     echo "Processor.$count.Name=$name"
     echo "Processor.$count.DeviceID=CPU$count"
     echo "Processor.$count.Family=32"
     echo "Processor.$count.AddressWidth=$width"
     echo "Processor.$count.DataWidth=$width"
     echo "Processor.$count.UniqueID=$proc_dir/"
     echo "Processor.$count.Manufacturer=IBM"

     procDone=0
     procFound=0
     cat /proc/cpuinfo | while read TAG SEP VAL
       do
       if [ "$procDone" = "1" ]; then
         continue
       fi
       if [ "$TAG" = "processor" ]; then
         if [ "$procFound" = "1" ]; then procDone=1
         elif [ "$VAL" = "$cpuid" ]; then procFound=1
         fi
       fi
       if [ "$procFound" = "0" ]; then
         continue
       fi
       if [ "$TAG" = "cpu" ]; then
         echo "Processor.$count.Model=$VAL"
       fi
       if [ "$TAG" = "clock" ]; then
         clock=${VAL%.*}
         echo "Processor.$count.CurrentClockSpeed=$clock"
       fi
       if [ "$TAG" = "revision" ]; then
         echo "Processor.$count.Version=$VAL"
       fi
     done
     count=`expr $count + 1`
  done
  return
}

####################################
# printDiskDrives
####################################
printDiskDrives()
{
  count=0
  for dasd_dir in /sys/block/hd*;
   do
     if [ "$dasd_dir" = "/sys/block/hd*" ]; then
       continue
     fi
     dasd_status=0
     dasd_devid=${dasd_dir#/sys/block/}
     echo "DiskDrive.$count.Name=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceID=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceType=2"
     if [ -f $dasd_dir/size ]; then
       dasd_size=`cat $dasd_dir/size`
       dasd_size=`expr $dasd_size / 2`
       echo "DiskDrive.$count.Capacity=$dasd_size"
     fi
     echo "DiskDrive.$count.OperatingState=8"
     count=`expr $count + 1`
  done
  count=0
  for dasd_dir in /sys/block/sd*;
   do
     if [ "$dasd_dir" = "/sys/block/sd*" ]; then
       continue
     fi
     dasd_status=0
     dasd_devid=${dasd_dir#/sys/block/}
     echo "DiskDrive.$count.Name=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceID=/dev/$dasd_devid"
     echo "DiskDrive.$count.DeviceType=2"
     if [ -f $dasd_dir/size ]; then
       dasd_size=`cat $dasd_dir/size`
       dasd_size=`expr $dasd_size / 2`
       echo "DiskDrive.$count.Capacity=$dasd_size"
     fi
     echo "DiskDrive.$count.OperatingState=8"
     count=`expr $count + 1`
  done
  return
}

####################################
# printDiskPartitions
####################################
printDiskPartitions()
{
  count=0
  cat /proc/partitions | grep 'dasd\|sd\|hd' | while read ONE TWO THREE FOUR FIVE
    do
      tempName=`echo $FOUR | grep '[0123456789]'`
      if [ "$tempName"  = "" ]; then
        continue
      fi
      echo "DiskPartition.$count.Name=/dev/$FOUR"
      echo "DiskPartition.$count.DeviceID=/dev/$FOUR"
      echo "DiskPartition.$count.NumberOfBlocks=$THREE"
      echo "DiskPartition.$count.Capacity=$THREE"
      echo "DiskPartition.$count.BlockSize=1"
      echo "DiskPartition.$count.PartitionType=2"
      echo "DiskPartition.$count.HealthState=1"
      count=`expr $count + 1`
    done
  return
}

####################################
# printLogicalVolumes
####################################
printLogicalVolumes()
{
  count=0
  cat /proc/partitions | grep 'dasd\|sd\|' | while read ONE TWO THREE FOUR FIVE
    do
      tempName=`echo $FOUR | grep '[0123456789]'`
      if [ "$tempName"  = "" ]; then
        continue
      fi
      echo "LogicalVolume.$count.Name=/dev/$FOUR"
      echo "LogicalVolume.$count.DeviceID=/dev/$FOUR"
      echo "LogicalVolume.$count.NumberOfBlocks=$THREE"
      echo "LogicalVolume.$count.Capacity=$THREE"
      echo "LogicalVolume.$count.BlockSize=1"
      echo "LogicalVolume.$count.HealthState=1"
      count=`expr $count + 1`
    done
  return
}

####################################
# printFileSystems
####################################
printFileSystems()
{
  count=0
  df -l -T -P -B 1 | sed '1d' | while read ONE TWO THREE FOUR FIVE SIX SEVEN
    do
      echo "FileSystem.$count.Name=$ONE"
      echo "FileSystem.$count.Root=$SEVEN"
      echo "FileSystem.$count.Label=$SEVEN"
      echo "FileSystem.$count.HealthState=1"
      echo "FileSystem.$count.AvailableSpace=$FIVE"
      echo "FileSystem.$count.FileSystemSize=$THREE"
      fsType="0"
      if [ "$TWO" = "jfs" ]; then fsType="1"; fi
      if [ "$TWO" = "nfs" ]; then fsType="25"; fi
      if [ "$TWO" = "ufs" ]; then fsType="19"; fi
      if [ "$TWO" = "vfs" ]; then fsType="9"; fi
      if [ "$TWO" = "xfs" ]; then fsType="23"; fi
      if [ "$TWO" = "udf" ]; then fsType="16"; fi
      if [ "$TWO" = "ext2" ]; then fsType="12"; fi
      if [ "$TWO" = "ext3" ]; then fsType="13"; fi
      if [ "$TWO" = "jfs2" ]; then fsType="3"; fi
      if [ "$TWO" = "ntfs" ]; then fsType="6"; fi
      if [ "$TWO" = "swap" ]; then fsType="22"; fi
      if [ "$TWO" = "fat16" ]; then fsType="8"; fi
      if [ "$TWO" = "fat32" ]; then fsType="7"; fi
      if [ "$TWO" = "namefs" ]; then fsType="26"; fi
      if [ "$TWO" = "reiserfs" ]; then fsType="14"; fi
      if [ "$TWO" = "linuxlvm" ]; then fsType="24"; fi
      echo "FileSystem.$count.FileSystemType=$fsType"
      count=`expr $count + 1`
    done
  return
}

####################################
# printNICs
####################################
printNICs()
{
  count=0
  lancount=0
  devicelist=`ifconfig | grep "Link encap" | sed /"Local Loopback"/d | cut -d ' ' -f 1`

  for netdevice in $devicelist
   do
    ipaddress=`ifconfig $netdevice | grep "inet addr" | tr -s ' ' ',' | cut -d , -f 3 | sed 's/addr://'`
    ipv6=`ifconfig $netdevice | grep "inet6 addr" | tr -s ' ' ',' | cut -d , -f 4 | sed 's/addr://'`
    subnetmask=`ifconfig $netdevice | grep "inet addr" | tr -s ' ' ',' | cut -d , -f 5 | sed 's/Mask://'`
    netdevice_stripped=`echo "$netdevice" | cut -d : -f 1`
    gateway=`route -n | grep "$netdevice_stripped" | grep "UG" | tr -s ' ' ',' | cut -d , -f 2`
    macaddrLine=`ifconfig $netdevice | grep "HWaddr"`
    macaddress=${macaddrLine#*HWaddr }
    macaddress=`echo $macaddress | sed s/://g`
    
    if [ "$ipv6" != "" ]; then
      for ip6info in $ipv6
      do
        prefixlen=${ip6info#*/}
        ip6address=${ip6info%/*}   
        echo "CSIPProtocolEndpoint.$count.Name=$ip6address"
        echo "CSIPProtocolEndpoint.$count.Gateway=$gateway"
        echo "CSIPProtocolEndpoint.$count.IPv6Address=$ip6address"
        echo "CSIPProtocolEndpoint.$count.HostType=CS"
        echo "CSIPProtocolEndpoint.$count.PrefixLength=$prefixlen" 
        echo "OSIPProtocolEndpoint.$count.Name=$ip6address"
        echo "OSIPProtocolEndpoint.$count.Gateway=$gateway"
        echo "OSIPProtocolEndpoint.$count.PrefixLength=$prefixlen"
        echo "OSIPProtocolEndpoint.$count.IPv6Address=$ip6address"
        echo "OSIPProtocolEndpoint.$count.HostType=OS"
        echo "CSBindsTo.$count.SourceId=$count"
        echo "CSBindsTo.$count.TargetId=$lancount"
        echo "OSBindsTo.$count.SourceId=$count"
        echo "OSBindsTo.$count.TargetId=$lancount"
        count=`expr $count + 1`
      done
    fi
    if [ "$ipaddress" != "" ]; then
      echo "CSIPProtocolEndpoint.$count.Name=$ipaddress"
      echo "CSIPProtocolEndpoint.$count.Gateway=$gateway"
      echo "CSIPProtocolEndpoint.$count.SubnetMask=$subnetmask"
      echo "CSIPProtocolEndpoint.$count.IPv4Address=$ipaddress"
      echo "CSIPProtocolEndpoint.$count.HostType=CS"
      echo "OSIPProtocolEndpoint.$count.Name=$ipaddress"
      echo "OSIPProtocolEndpoint.$count.Gateway=$gateway"
      echo "OSIPProtocolEndpoint.$count.SubnetMask=$subnetmask"
      echo "OSIPProtocolEndpoint.$count.IPv4Address=$ipaddress"
      echo "OSIPProtocolEndpoint.$count.HostType=OS"
      echo "CSBindsTo.$count.SourceId=$count"
      echo "CSBindsTo.$count.TargetId=$lancount"
      echo "OSBindsTo.$count.SourceId=$count"
      echo "OSBindsTo.$count.TargetId=$lancount"
      count=`expr $count + 1`
    fi
    if [ "$ipaddress" != "" ] || [ "$ip6info" != "" ]; then
      echo "CSLANEndpoint.$lancount.Name=$macaddress"
      echo "CSLANEndpoint.$lancount.DisplayName=$netdevice_stripped"
      echo "CSLANEndpoint.$lancount.DeviceName=$netdevice_stripped"
      echo "CSLANEndpoint.$lancount.MACAddress=$macaddress"
      echo "CSLANEndpoint.$lancount.HostType=CS"
      echo "OSLANEndpoint.$lancount.Name=$macaddress"
      echo "OSLANEndpoint.$lancount.DisplayName=$netdevice_stripped"
      echo "OSLANEndpoint.$lancount.DeviceName=$netdevice_stripped"
      echo "OSLANEndpoint.$lancount.MACAddress=$macaddress"
      echo "OSLANEndpoint.$lancount.HostType=OS"
      lancount=`expr $lancount + 1`
    fi

  done
  return
}

####################################
# printMetaInfo
####################################
printMetaInfo()
{
# --PhysicalFrame-- #
  echo "Resource.PhysicalFrame.ClassName=PhysicalFrame"
  echo "Resource.PhysicalFrame.Defer=true"
  echo "Resource.PhysicalFrame.Keys=Tag"
  echo "Relationship.PhysicalFrameCS.ClassName=ComputerSystemContainsPhysicalElement"
  echo "Relationship.PhysicalFrameCS.Defer=true"
  echo "Relationship.PhysicalFrameCS.Implicit=true"
  echo "Relationship.PhysicalFrameCS.SourceClass=Server"
  echo "Relationship.PhysicalFrameCS.TargetClass=PhysicalFrame"
# --Processor-- #
  echo "Resource.Processor.ClassName=Processor"
  echo "Resource.Processor.Defer=true"
  echo "Resource.Processor.Keys=DeviceID"
  echo "Relationship.ProcessorCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.ProcessorCS.Defer=true"
  echo "Relationship.ProcessorCS.Implicit=true"
  echo "Relationship.ProcessorCS.SourceClass=Server"
  echo "Relationship.ProcessorCS.TargetClass=Processor"
# --DiskDrive-- #
  echo "Resource.DiskDrive.ClassName=DiskDrive"
  echo "Resource.DiskDrive.Keys=DeviceID"
  echo "Relationship.DiskDriveCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.DiskDriveCS.Implicit=true"
  echo "Relationship.DiskDriveCS.SourceClass=Server"
  echo "Relationship.DiskDriveCS.TargetClass=DiskDrive"
# --DiskPartition-- #
  echo "Resource.DiskPartition.ClassName=DiskPartition"
  echo "Resource.DiskPartition.Keys=DeviceID"
  echo "Relationship.DiskPartitionCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.DiskPartitionCS.Implicit=true"
  echo "Relationship.DiskPartitionCS.SourceClass=Server"
  echo "Relationship.DiskPartitionCS.TargetClass=DiskPartition"
# --LogicalVolume-- #
  echo "Resource.LogicalVolume.ClassName=LogicalVolume"
  echo "Resource.LogicalVolume.Keys=DeviceID"
  echo "Relationship.LogicalVolumeCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.LogicalVolumeCS.Implicit=true"
  echo "Relationship.LogicalVolumeCS.SourceClass=Server"
  echo "Relationship.LogicalVolumeCS.TargetClass=LogicalVolume"
# --FileSystem-- #
  echo "Resource.FileSystem.ClassName=FileSystem"
  echo "Resource.FileSystem.Keys=Name"
  echo "Relationship.FileSystemCS.ClassName=ComputerSystemContainsFileSystem"
  echo "Relationship.FileSystemCS.Implicit=true"
  echo "Relationship.FileSystemCS.SourceClass=Server"
  echo "Relationship.FileSystemCS.TargetClass=FileSystem"
# --NICs-- #
  echo "Resource.CSLANEndpoint.ClassName=LANEndpoint"
  echo "Resource.CSLANEndpoint.Keys=Name,HostType"
  echo "Resource.OSLANEndpoint.ClassName=LANEndpoint"
  echo "Resource.OSLANEndpoint.Keys=Name,HostType"
  echo "Resource.CSIPProtocolEndpoint.ClassName=IPProtocolEndpoint"
  echo "Resource.CSIPProtocolEndpoint.Keys=Name,HostType"
  echo "Resource.OSIPProtocolEndpoint.ClassName=IPProtocolEndpoint"
  echo "Resource.OSIPProtocolEndpoint.Keys=Name,HostType"
  echo "Relationship.LANEndpointCS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.LANEndpointCS.Implicit=true"
  echo "Relationship.LANEndpointCS.SourceClass=Server"
  echo "Relationship.LANEndpointCS.TargetClass=LANEndpoint"
  echo "Relationship.LANEndpointCS.TargetAlias=CSLANEndpoint"
  echo "Relationship.IPProtocolEndpointCS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointCS.Implicit=true"
  echo "Relationship.IPProtocolEndpointCS.SourceClass=Server"
  echo "Relationship.IPProtocolEndpointCS.TargetClass=IPProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointCS.TargetAlias=CSIPProtocolEndpoint"
  echo "Relationship.LANEndpointOS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.LANEndpointOS.Implicit=true"
  echo "Relationship.LANEndpointOS.SourceClass=OperatingSystem"
  echo "Relationship.LANEndpointOS.TargetClass=LANEndpoint"
  echo "Relationship.LANEndpointOS.TargetAlias=OSLANEndpoint"
  echo "Relationship.IPProtocolEndpointOS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointOS.Implicit=true"
  echo "Relationship.IPProtocolEndpointOS.SourceClass=OperatingSystem"
  echo "Relationship.IPProtocolEndpointOS.TargetClass=IPProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointOS.TargetAlias=OSIPProtocolEndpoint"
  echo "Relationship.CSBindsTo.ClassName=ProtocolEndpointBindsToProtocolEndpoint"
  echo "Relationship.CSBindsTo.SourceClass=IPProtocolEndpoint"
  echo "Relationship.CSBindsTo.SourceAlias=CSIPProtocolEndpoint"
  echo "Relationship.CSBindsTo.TargetClass=LANEndpoint"
  echo "Relationship.CSBindsTo.TargetAlias=CSLANEndpoint"
  echo "Relationship.OSBindsTo.ClassName=ProtocolEndpointBindsToProtocolEndpoint"
  echo "Relationship.OSBindsTo.SourceClass=IPProtocolEndpoint"
  echo "Relationship.OSBindsTo.SourceAlias=OSIPProtocolEndpoint"
  echo "Relationship.OSBindsTo.TargetClass=LANEndpoint"
  echo "Relationship.OSBindsTo.TargetAlias=OSLANEndpoint"
# --vpd cod data-- #
  echo Resource.Card.ClassName=Card
  echo Resource.Card.Keys=Tag
  echo Resource.ResourceCapacity.ClassName=ResourceCapacity
  echo Resource.ResourceCapacity.Keys=SettingID
  echo Relationship.CardCS.ClassName=ComputerSystemContainsPhysicalElement
  echo Relationship.CardCS.Implicit=true
  echo Relationship.CardCS.SourceClass=Server
  echo Relationship.CardCS.TargetClass=Card
  echo Relationship.ResourceCapCS.ClassName=ComputerSystemDefinedUsingResourceCapacity
  echo Relationship.ResourceCapCS.Implicit=true
  echo Relationship.ResourceCapCS.SourceClass=Server
  echo Relationship.ResourceCapCS.TargetClass=ResourceCapacity
  echo Relationship.CardResourceCap.ClassName=ResourceCapacityDeterminedByCard
  echo Relationship.CardResourceCap.SourceClass=ResourceCapacity
  echo Relationship.CardResourceCap.TargetClass=Card
  echo Resource.PhysicalMemory.ClassName=PhysicalMemory
  echo Resource.PhysicalMemory.Keys=Tag
  echo Resource.PhysicalPort.ClassName=PhysicalPort
  echo Resource.PhysicalPort.Keys=Tag
  echo Resource.PhysicalPackage.ClassName=PhysicalPackage
  echo Resource.PhysicalPackage.Keys=Tag
  echo Relationship.PhysicalMemoryCS.ClassName=ComputerSystemContainsPhysicalElement
  echo Relationship.PhysicalMemoryCS.Implicit=true
  echo Relationship.PhysicalMemoryCS.SourceClass=Server
  echo Relationship.PhysicalMemoryCS.TargetClass=PhysicalMemory
  echo Relationship.PhysicalPortCS.ClassName=ComputerSystemContainsPhysicalElement
  echo Relationship.PhysicalPortCS.Implicit=true
  echo Relationship.PhysicalPortCS.SourceClass=Server
  echo Relationship.PhysicalPortCS.TargetClass=PhysicalPort
  echo Relationship.PhysicalPackageCS.ClassName=ComputerSystemContainsPhysicalElement
  echo Relationship.PhysicalPackageCS.Implicit=true
  echo Relationship.PhysicalPackageCS.SourceClass=Server
  echo Relationship.PhysicalPackageCS.TargetClass=PhysicalPackage
  return
}

####################################
# printlsvpd
####################################
printlsvpd()
{
  lsvpd>teststr
  startStanzaBool=true
  startStanza="*FC ????????"
  while read line
  do
    if echo "$line" | grep "\*N5">0; then
      if echo "$line" | grep "\BASE">0; then
        printN5EnhancedData
      else
        printN5Data
      fi
    fi
    if echo "$line" | grep "\*N6">0; then
      if echo "$line" | grep "\BASE">0; then
        printN6EnhancedData
      else
        printN6Data
      fi
    fi
    if [ "$line" == "$startStanza" ]; then
      if [ "$startStanzaBool" == "true" ]; then
        startStanzaBool=false
        globalstrval=""
        rm -f tempstanza
        echo "$line">locationCodeFile
        echo "$line">relationshipFile
      else
        parseLocationCode
        globalstrval=""
        rm -f tempstanza
      fi
    fi
    echo $line>>tempstanza
  done < teststr
return
}

####################################
# parseLocationCode
####################################
parseLocationCode()
{
#  while read line
 locationcodefromfile=`awk '/'"\*YL"'/ {print;exit }' tempstanza` 
#  do
    locationCode="$locationcodefromfile"
#    if echo "$locationcodefromfile" | grep "\*YL">0; then
      if  echo "$locationcodefromfile" | grep 'YL U' >0; then
       dummyvar=0 ;
      else
        return;
      fi

      if  echo "$locationcodefromfile" | grep '/' >0; then
        return;
      fi

      if  echo "$locationcodefromfile" | egrep '\-L|\-A|\-E' >0; then
        return;
      fi
checkLocationCode
      if  echo "$locationcodefromfile" | grep "\-D">0; then
#        checkLocationCode
        if [  "$isLocationCodeDuplicate" == $"false" ]; then
          printDiskData
          return;
        fi
      fi
      if  echo "$locationcodefromfile" | grep  "\-P">0; then
        dashpIndex=`expr index "$locationcodefromfile" \-`
        substringAfterDash=${locationcodefromfile:$dashpIndex}
        if echo "$substringAfterDash" | grep "\-">0; then
          dummyvar=0
        else
#          checkLocationCode
          if [  "$isLocationCodeDuplicate" == $"false" ]; then
            printPlanerData
            return;
          fi
        fi
      fi
      if  echo "$locationcodefromfile" | grep  "\-T">0; then
#        checkLocationCode
        if [  "$isLocationCodeDuplicate" == $"false" ]; then
          printPortData
          return;
        fi
      fi
      if  echo "$locationcodefromfile" | grep  "\-C">0; then
#        checkLocationCode
        if [  "$isLocationCodeDuplicate" == $"false" ]; then
          printCardData
          return;
        fi
      fi
      if (stringline="$locationcodefromfile"; [[ "$stringline" =~ "YL U" ]] ); then
        if (dashline="$locationcodefromfile"; [[ "$dashline" =~ "-" ]] ); then
          dummyvar=0
        else
#          checkLocationCode
          if [  "$isLocationCodeDuplicate" == $"false" ]; then
            printPhysicalFrameData
            return;
          fi
        fi
      fi
#    fi
#  done < tempstanza
  return
}

####################################
# printN5Data
####################################
printN5Data()
{
  machtype=`echo "$line" | cut -b5-8`
  serial=`echo "$line" | cut -b9-18`
  CCIN=`echo "$line" | cut -b19-22`
  cardser=`echo "$line" | cut -b23-32`
  cardId=`echo "$line" | cut -b33-48`

  echo "Card.$pIndex.Name=Capacity Card"
  echo "Card.$pIndex.Tag=$cardId"
  echo "Card.$pIndex.Manufacturer=IBM"
  echo "Card.$pIndex.VendorEquipmentType=$CCIN"
  echo "Card.$pIndex.SerialNumber=$cardser"

  feature=`echo "$line" | cut -b49-52`
  actres=`echo "$line" | cut -b53-56`
  actseqnum=`echo "$line" | cut -b57-60`
  actchecksum=`echo "$line" | cut -b61-62`
  avalres=`echo "$line" | cut -b63-66`

  echo "ResourceCapacity.$rcindex.Name=Permanent Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Permanent"
  echo "ResourceCapacity.$rcindex.Enabled=true"
  echo "ResourceCapacity.$rcindex.Active=true"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=4"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$actres"
  echo "ResourceCapacity.$rcindex.Minimum=$avalres"
  echo "ResourceCapacity.$rcindex.Sequence=$actseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$actchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$feature"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  codenable=`echo "$line" | cut -b67-67`
  if [[ $codenable == "1" ]]; then
     codenable="true"
  else
     codenable="false"
  fi
  codactive=`echo "$line" | cut -b68-68`
  if [[ $codactive == "1" ]]; then
     codactive="true"
  else
     codactive="false"
  fi
  codfeature=`echo "$line" | cut -b69-72`
  codactresource=`echo "$line" | cut -b73-76`
  codseqnum=`echo "$line" | cut -b77-81`
  codchecksum=`echo "$line" | cut -b81-82`
  codresreq=`echo "$line" | cut -b83-86`
  coddaysreq=`echo "$line" | cut -b87-90`
  coddaysexp=`echo "$line" | cut -b91-94`
  coddaysrem=`echo "$line" | cut -b95-98`
  codcnt=`echo "$line" | cut -b99-102`
  codstandbyres=`echo "$line" | cut -b103-106`
  # 1 reserved byte
  codhisreqdays=`echo "$line" | cut -b108-111`
  # 1 reserved byte
  codhisunretdays=`echo "$line" | cut -b113-116`

  echo "ResourceCapacity.$rcindex.Name=Temporary Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Temporary"
  echo "ResourceCapacity.$rcindex.Enabled=$codenable"
  echo "ResourceCapacity.$rcindex.Active=$codactive"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=5"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$codactresource"
  echo "ResourceCapacity.$rcindex.Limit=$codresreq"
  echo "ResourceCapacity.$rcindex.Minimum=$codstandbyres"
  echo "ResourceCapacity.$rcindex.Sequence=$codseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$codchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$codfeature"
  echo "ResourceCapacity.$rcindex.DaysRequested=$coddaysreq"
  echo "ResourceCapacity.$rcindex.DaysExpired=$coddaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$coddaysrem"
 
  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"
 
  rcindex=`expr $rcindex + 1`

  debitenable=`echo "$line" | cut -b117-117`
  if [[ $debitenable == "1" ]]; then
     debitenable="true"
  else
     debitenable="false"
  fi
  debitactive=`echo "$line" | cut -b118-118`
  if [[ $debitactive == "1" ]]; then
     debitactive="true"
  else
     debitactive="false"
  fi
  debitfeature=`echo "$line" | cut -b119-122`
  debitactproc=`echo "$line" | cut -b123-126`
  debitseqnum=`echo "$line" | cut -b127-130`
  debitchecksum=`echo "$line" | cut -b131-132`
  debitprocreq=`echo "$line" | cut -b133-136`
  # 12 reserved bytes
  debitcnt=`echo "$line" | cut -b149-152`
  debitstanproc=`echo "$line" | cut -b153-156`
  # 1 reserved byte
  debithisexprocdays=`echo "$line" | cut -b158-161`
  # 1 reserved byte
  debithisunretprocdays=`echo "$line" | cut -b163-166`
  # 16 reserved bytes

  echo "ResourceCapacity.$rcindex.Name=Metered Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Debit"
  echo "ResourceCapacity.$rcindex.Enabled=$debitenable"
  echo "ResourceCapacity.$rcindex.Active=$debitactive"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=7"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$debitactproc"
  echo "ResourceCapacity.$rcindex.Limit=$debitprocres"
  echo "ResourceCapacity.$rcindex.Minimum=$debitstanproc"
  echo "ResourceCapacity.$rcindex.Sequence=$debitseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$debitchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$debitfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$debithisexprocdays"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  trialenable=`echo "$line" | cut -b183-183`
  if [[ $trialenable == "1" ]]; then
     trialenable="true"
  else
     trialenable="false"
  fi
  # 1 reserved byte
  trialfeature=`echo "$line" | cut -b185-188`
  trialactres=`echo "$line" | cut -b189-192`
  trialseqnum=`echo "$line" | cut -b193-196`
  trialchecksum=`echo "$line" | cut -b197-198`
  # 8 reserved bytes
  trialdaysexp=`echo "$line" | cut -b207-210`
  trialdaysrem=`echo "$line" | cut -b211-214`
  # 14 reserved bytes
  trialunretres=`echo "$line" | cut -b229-232`
    
  echo "ResourceCapacity.$rcindex.Name=Trial Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Trial"
  echo "ResourceCapacity.$rcindex.Enabled=$trialenable"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=6"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$trialactres"
  echo "ResourceCapacity.$rcindex.Sequence=$trialseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$trialchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$trialfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$trialdaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$trialdaysrem"
    
  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"
    
  rcindex=`expr $rcindex + 1`
  pIndex=`expr $pIndex + 1`
                    
  return
}
####################################
# printN5EnhancedData
####################################
printN5EnhancedData()
{
  machtype=`echo "$line" | cut -b29-32`
  serial=`echo "$line" | cut -b33-42`
  CCIN=`echo "$line" | cut -b43-46`
  cardser=`echo "$line" | cut -b47-56`
  cardId=`echo "$line" | cut -b57-72`

  echo "Card.$pIndex.Name=Capacity Card"
  echo "Card.$pIndex.Tag=$cardId"
  echo "Card.$pIndex.Manufacturer=IBM"
  echo "Card.$pIndex.VendorEquipmentType=$CCIN"
  echo "Card.$pIndex.SerialNumber=$cardser"

  feature=`echo "$line" | cut -b73-76`
  actres=`echo "$line" | cut -b77-80`
  actseqnum=`echo "$line" | cut -b81-84`
  actchecksum=`echo "$line" | cut -b85-86`
  avalres=`echo "$line" | cut -b87-90`

  echo "ResourceCapacity.$rcindex.Name=Permanent Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Permanent"
  echo "ResourceCapacity.$rcindex.Enabled=true"
  echo "ResourceCapacity.$rcindex.Active=true"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=4"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$actres"
  echo "ResourceCapacity.$rcindex.Minimum=$avalres"
  echo "ResourceCapacity.$rcindex.Sequence=$actseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$actchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$feature"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  codenable=`echo "$line" | cut -b107-107`
  if [[ $codenable == "1" ]]; then
     codenable="true"
  else
     codenable="false"
  fi
  codactive=`echo "$line" | cut -b108-108`
  if [[ $codactive == "1" ]]; then
     codactive="true"
  else
     codactive="false"
  fi
  codfeature=`echo "$line" | cut -b109-112`
  codactresource=`echo "$line" | cut -b113-116`
  codseqnum=`echo "$line" | cut -b117-120`
  codchecksum=`echo "$line" | cut -b121-122`
  codresreq=`echo "$line" | cut -b123-126`
  coddaysreq=`echo "$line" | cut -b127-130`
  coddaysexp=`echo "$line" | cut -b131-134`
  coddaysrem=`echo "$line" | cut -b135-138`
  codcnt=`echo "$line" | cut -b139-142`
  codstandbyres=`echo "$line" | cut -b143-146`
  # 1 reserved byte
  codhisreqdays=`echo "$line" | cut -b148-151`
  # 1 reserved byte
  codhisunretdays=`echo "$line" | cut -b153-156`

  echo "ResourceCapacity.$rcindex.Name=Temporary Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Temporary"
  echo "ResourceCapacity.$rcindex.Enabled=$codenable"
  echo "ResourceCapacity.$rcindex.Active=$codactive"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=5"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$codactresource"
  echo "ResourceCapacity.$rcindex.Limit=$codresreq"
  echo "ResourceCapacity.$rcindex.Minimum=$codstandbyres"
  echo "ResourceCapacity.$rcindex.Sequence=$codseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$codchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$codfeature"
  echo "ResourceCapacity.$rcindex.DaysRequested=$coddaysreq"
  echo "ResourceCapacity.$rcindex.DaysExpired=$coddaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$coddaysrem"
 
  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"
 
  rcindex=`expr $rcindex + 1`

  debitenable=`echo "$line" | cut -b173-173`
  if [[ $debitenable == "1" ]]; then
     debitenable="true"
  else
     debitenable="false"
  fi
  debitactive=`echo "$line" | cut -b174-174`
  if [[ $debitactive == "1" ]]; then
     debitactive="true"
  else
     debitactive="false"
  fi
  debitfeature=`echo "$line" | cut -b175-178`
  debitactproc=`echo "$line" | cut -b179-182`
  debitseqnum=`echo "$line" | cut -b183-186`
  debitchecksum=`echo "$line" | cut -b187-188`
  debitprocreq=`echo "$line" | cut -b189-192`
  # 12 reserved bytes
  debitcnt=`echo "$line" | cut -b205-208`
  debitstanproc=`echo "$line" | cut -b209-212`
  # 1 reserved byte
  debithisexprocdays=`echo "$line" | cut -b214-217`
  # 1 reserved byte
  debithisunretprocdays=`echo "$line" | cut -b219-222`
  # 8 reserved bytes - Ext total history of requested Proc days
  # 8 reserver bytes - Ext total history if unreturned Proc days

  echo "ResourceCapacity.$rcindex.Name=Metered Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Debit"
  echo "ResourceCapacity.$rcindex.Enabled=$debitenable"
  echo "ResourceCapacity.$rcindex.Active=$debitactive"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=7"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$debitactproc"
  echo "ResourceCapacity.$rcindex.Limit=$debitprocres"
  echo "ResourceCapacity.$rcindex.Minimum=$debitstanproc"
  echo "ResourceCapacity.$rcindex.Sequence=$debitseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$debitchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$debitfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$debithisexprocdays"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  trialenable=`echo "$line" | cut -b255-255`
  if [[ $trialenable == "1" ]]; then
     trialenable="true"
  else
     trialenable="false"
  fi
  # 1 reserved byte
  trialfeature=`echo "$line" | cut -b257-260`
  trialactres=`echo "$line" | cut -b261-264`
  trialseqnum=`echo "$line" | cut -b265-268`
  trialchecksum=`echo "$line" | cut -b269-270`
  # 8 reserved bytes
  trialdaysexp=`echo "$line" | cut -b279-282`
  trialdaysrem=`echo "$line" | cut -b283-286`
  # 14 reserved bytes
  trialunretres=`echo "$line" | cut -b302-305`

  echo "ResourceCapacity.$rcindex.Name=Trial Processor Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Processor.Trial"
  echo "ResourceCapacity.$rcindex.Enabled=$trialenable"
  echo "ResourceCapacity.$rcindex.ResourceType=3"
  echo "ResourceCapacity.$rcindex.CapacityType=6"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$trialactres"
  echo "ResourceCapacity.$rcindex.Sequence=$trialseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$trialchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$trialfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$trialdaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$trialdaysrem"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`
  pIndex=`expr $pIndex + 1`

  return
}
####################################
# printN6Data
####################################
printN6Data()
{
  machtype=`echo "$line" | cut -b5-8`
  serial=`echo "$line" | cut -b9-18`
  CCIN=`echo "$line" | cut -b19-22`
  cardser=`echo "$line" | cut -b23-32`
  cardId=`echo "$line" | cut -b33-48`

  echo "Card.$pIndex.Name=Capacity Card"
  echo "Card.$pIndex.Tag=$cardId"
  echo "Card.$pIndex.Manufacturer=IBM"
  echo "Card.$pIndex.VendorEquipmentType=$CCIN"
  echo "Card.$pIndex.SerialNumber=$cardser"

  feature=`echo "$line" | cut -b49-52`
  actres=`echo "$line" | cut -b53-56`
  actseqnum=`echo "$line" | cut -b57-60`
  actchecksum=`echo "$line" | cut -b61-62`
  avalres=`echo "$line" | cut -b63-66`

  echo "ResourceCapacity.$rcindex.Name=Permanent Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Permanent"
  echo "ResourceCapacity.$rcindex.Enabled=true"
  echo "ResourceCapacity.$rcindex.Active=true"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=4"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$actres"
  echo "ResourceCapacity.$rcindex.Minimum=$avalres"
  echo "ResourceCapacity.$rcindex.Sequence=$actseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$actchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$feature"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  codenable=`echo "$line" | cut -b67-67`
  if [[ $codenable == "1" ]]; then
     codenable="true"
  else
     codenable="false"
  fi
  codactive=`echo "$line" | cut -b68-68`
  if [[ $codactive == "1" ]]; then
     codactive="true"
  else
     codactive="false"
  fi
  codfeature=`echo "$line" | cut -b69-72`
  codactresource=`echo "$line" | cut -b73-76`
  codseqnum=`echo "$line" | cut -b77-81`
  codchecksum=`echo "$line" | cut -b81-82`
  codresreq=`echo "$line" | cut -b83-86`
  coddaysreq=`echo "$line" | cut -b87-90`
  coddaysexp=`echo "$line" | cut -b91-94`
  coddaysrem=`echo "$line" | cut -b95-98`
  codcnt=`echo "$line" | cut -b99-102`
  codstandbyres=`echo "$line" | cut -b103-106`
  # 1 reserved byte
  codhisreqdays=`echo "$line" | cut -b108-111`
  # 1 reserved byte
  codhisunretdays=`echo "$line" | cut -b113-116`
  memmult=`echo "$line" | cut -b117-117`

  echo "ResourceCapacity.$rcindex.Name=Temporary Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Temporary"
  echo "ResourceCapacity.$rcindex.Enabled=$codenable"
  echo "ResourceCapacity.$rcindex.Active=$codactive"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=5"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$codactresource"
  echo "ResourceCapacity.$rcindex.Limit=$codresreq"
  echo "ResourceCapacity.$rcindex.Minimum=$codstandbyres"
  echo "ResourceCapacity.$rcindex.Sequence=$codseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$codchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$codfeature"
  echo "ResourceCapacity.$rcindex.DaysRequested=$coddaysreq"
  echo "ResourceCapacity.$rcindex.DaysExpired=$coddaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$coddaysrem"
 
  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"
 
  rcindex=`expr $rcindex + 1`

  debitenable=`echo "$line" | cut -b118-118`
  if [[ $debitenable == "1" ]]; then
     debitenable="true"
  else
     debitenable="false"
  fi
  debitactive=`echo "$line" | cut -b119-119`
  if [[ $debitactive == "1" ]]; then
     debitactive="true"
  else
     debitactive="false"
  fi
  debitfeature=`echo "$line" | cut -b120-123`
  debitactproc=`echo "$line" | cut -b124-127`
  debitseqnum=`echo "$line" | cut -b128-131`
  debitchecksum=`echo "$line" | cut -b132-133`
  debitprocreq=`echo "$line" | cut -b134-137`
  # 12 reserved bytes
  debitcnt=`echo "$line" | cut -b150-153`
  debitstanproc=`echo "$line" | cut -b154-157`
  # 1 reserved byte
  debithisexprocdays=`echo "$line" | cut -b159-162`
  # 1 reserved byte
  debithisunretprocdays=`echo "$line" | cut -b164-167`
  # 16 reserved bytes
  # 1 reserved byte 

  echo "ResourceCapacity.$rcindex.Name=Metered Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Debit"
  echo "ResourceCapacity.$rcindex.Enabled=$debitenable"
  echo "ResourceCapacity.$rcindex.Active=$debitactive"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=7"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$debitactproc"
  echo "ResourceCapacity.$rcindex.Limit=$debitprocres"
  echo "ResourceCapacity.$rcindex.Minimum=$debitstanproc"
  echo "ResourceCapacity.$rcindex.Sequence=$debitseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$debitchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$debitfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$debithisexprocdays"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  trialenable=`echo "$line" | cut -b185-185`
  if [[ $trialenable == "1" ]]; then
     trialenable="true"
  else
     trialenable="false"
  fi
  # 1 reserved byte
  trialfeature=`echo "$line" | cut -b187-190`
  trialactres=`echo "$line" | cut -b191-194`
  trialseqnum=`echo "$line" | cut -b195-198`
  trialchecksum=`echo "$line" | cut -b199-200`
  # 8 reserved bytes
  trialdaysexp=`echo "$line" | cut -b209-212`
  trialdaysrem=`echo "$line" | cut -b213-216`
  # 14 reserved bytes
  trialunretres=`echo "$line" | cut -b231-234`
  # 1 reserved byte`

  echo "ResourceCapacity.$rcindex.Name=Trial Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Trial"
  echo "ResourceCapacity.$rcindex.Enabled=$trialenable"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=6"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$trialactres"
  echo "ResourceCapacity.$rcindex.Sequence=$trialseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$trialchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$trialfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$trialdaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$trialdaysrem"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`
  pIndex=`expr $pIndex + 1`
  
  return 
}

####################################
# printN6EnhancedData
####################################
printN6EnhancedData()
{
  machtype=`echo "$line" | cut -b29-32`
  serial=`echo "$line" | cut -b33-42`
  CCIN=`echo "$line" | cut -b43-46`
  cardser=`echo "$line" | cut -b47-56`
  cardId=`echo "$line" | cut -b57-72`

  echo "Card.$pIndex.Name=Capacity Card"
  echo "Card.$pIndex.Tag=$cardId"
  echo "Card.$pIndex.Manufacturer=IBM"
  echo "Card.$pIndex.VendorEquipmentType=$CCIN"
  echo "Card.$pIndex.SerialNumber=$cardser"

  feature=`echo "$line" | cut -b73-76`
  actres=`echo "$line" | cut -b77-80`
  actseqnum=`echo "$line" | cut -b81-84`
  actchecksum=`echo "$line" | cut -b85-86`
  avalres=`echo "$line" | cut -b87-90`

  echo "ResourceCapacity.$rcindex.Name=Permanent Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Permanent"
  echo "ResourceCapacity.$rcindex.Enabled=true"
  echo "ResourceCapacity.$rcindex.Active=true"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=4"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$actres"
  echo "ResourceCapacity.$rcindex.Minimum=$avalres"
  echo "ResourceCapacity.$rcindex.Sequence=$actseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$actchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$feature"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  codenable=`echo "$line" | cut -b107-107`
  if [[ $codenable == "1" ]]; then
     codenable="true"
  else
     codenable="false"
  fi
  codactive=`echo "$line" | cut -b108-108`
  if [[ $codactive == "1" ]]; then
     codactive="true"
  else
     codactive="false"
  fi
  codfeature=`echo "$line" | cut -b109-112`
  codactresource=`echo "$line" | cut -b113-116`
  codseqnum=`echo "$line" | cut -b117-120`
  codchecksum=`echo "$line" | cut -b121-122`
  codresreq=`echo "$line" | cut -b123-126`
  coddaysreq=`echo "$line" | cut -b127-130`
  coddaysexp=`echo "$line" | cut -b131-134`
  coddaysrem=`echo "$line" | cut -b135-138`
  codcnt=`echo "$line" | cut -b139-142`
  codstandbyres=`echo "$line" | cut -b143-146`
  # 1 reserved byte
  codhisreqdays=`echo "$line" | cut -b148-151`
  # 1 reserved byte
  codhisunretdays=`echo "$line" | cut -b153-156`
  memmult=`echo "$line" | cut -b157-157`

  echo "ResourceCapacity.$rcindex.Name=Temporary Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Temporary"
  echo "ResourceCapacity.$rcindex.Enabled=$codenable"
  echo "ResourceCapacity.$rcindex.Active=$codactive"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=5"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$codactresource"
  echo "ResourceCapacity.$rcindex.Limit=$codresreq"
  echo "ResourceCapacity.$rcindex.Minimum=$codstandbyres"
  echo "ResourceCapacity.$rcindex.Sequence=$codseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$codchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$codfeature"
  echo "ResourceCapacity.$rcindex.DaysRequested=$coddaysreq"
  echo "ResourceCapacity.$rcindex.DaysExpired=$coddaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$coddaysrem"
 
  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"
 
  rcindex=`expr $rcindex + 1`

  debitenable=`echo "$line" | cut -b174-174`
  if [[ $debitenable == "1" ]]; then
     debitenable="true"
  else
     debitenable="false"
  fi
  debitactive=`echo "$line" | cut -b175-175`
  if [[ $debitactive == "1" ]]; then
     debitactive="true"
  else
     debitactive="false"
  fi
  debitfeature=`echo "$line" | cut -b176-179`
  debitactproc=`echo "$line" | cut -b180-183`
  debitseqnum=`echo "$line" | cut -b184-187`
  debitchecksum=`echo "$line" | cut -b188-189`
  debitprocreq=`echo "$line" | cut -b190-193`
  # 12 reserved bytes
  debitcnt=`echo "$line" | cut -b206-209`
  debitstanproc=`echo "$line" | cut -b210-213`
  # 1 reserved byte
  debithisexprocdays=`echo "$line" | cut -b215-218`
  # 1 reserved byte
  debithisunretprocdays=`echo "$line" | cut -b220-223`
  # 8 reserved bytes - Ext total history of requested Memory days
  # 8 reserved bytes - Ext total history if unreturned Memory days
  # 1 reserved byte

  echo "ResourceCapacity.$rcindex.Name=Metered Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Debit"
  echo "ResourceCapacity.$rcindex.Enabled=$debitenable"
  echo "ResourceCapacity.$rcindex.Active=$debitactive"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=7"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$debitactproc"
  echo "ResourceCapacity.$rcindex.Limit=$debitprocres"
  echo "ResourceCapacity.$rcindex.Minimum=$debitstanproc"
  echo "ResourceCapacity.$rcindex.Sequence=$debitseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$debitchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$debitfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$debithisexprocdays"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`

  trialenable=`echo "$line" | cut -b257-257`
  if [[ $trialenable == "1" ]]; then
     trialenable="true"
  else
     trialenable="false"
  fi
  # 1 reserved byte
  trialfeature=`echo "$line" | cut -b259-262`
  trialactres=`echo "$line" | cut -b263-266`
  trialseqnum=`echo "$line" | cut -b267-270`
  trialchecksum=`echo "$line" | cut -b271-272`
  # 8 reserved bytes
  trialdaysexp=`echo "$line" | cut -b281-284`
  trialdaysrem=`echo "$line" | cut -b285-288`
  # 14 reserved bytes
  trialunretres=`echo "$line" | cut -b303-306`
  # 1 reserved byte

  echo "ResourceCapacity.$rcindex.Name=Trial Memory Capacity on Demand"
  echo "ResourceCapacity.$rcindex.SettingID=CoD.Memory.Trial"
  echo "ResourceCapacity.$rcindex.Enabled=$trialenable"
  echo "ResourceCapacity.$rcindex.ResourceType=4"
  echo "ResourceCapacity.$rcindex.CapacityType=6"
  echo "ResourceCapacity.$rcindex.SnapshotPurpose=Verification"
  echo "ResourceCapacity.$rcindex.Reservation=$trialactres"
  echo "ResourceCapacity.$rcindex.Sequence=$trialseqnum"
  echo "ResourceCapacity.$rcindex.Checksum=$trialchecksum"
  echo "ResourceCapacity.$rcindex.ResourceIdentifier=$trialfeature"
  echo "ResourceCapacity.$rcindex.DaysExpired=$trialdaysexp"
  echo "ResourceCapacity.$rcindex.DaysRemaining=$trialdaysrem"

  echo "CardResourceCap.$rcindex.SourceId=$rcindex"
  echo "CardResourceCap.$rcindex.TargetId=$pIndex"

  rcindex=`expr $rcindex + 1`
  pIndex=`expr $pIndex + 1`

  return
}
####################################
# checkLocationCode
####################################
checkLocationCode()
{
  stringFound="false"

# awk '/""$locationCode""/ {print;stringFound=true;}' locationCodeFile 
#tempValueOf=`awk '/'\"$locationCode\"'/ {print;stringFound=true;}' locationCodeFile`
#locationCode=`echo $locationCode | cut -d " " -f2-`
#stringFound=`awk '/'"$locationCode"'/ {print "true";exit}'  locationCodeFile`
  while read lineivar; do
    if [ "$lineivar" == "$locationCode" ]; then
      stringFound=true
    fi
  done<locationCodeFile
  if [  "$stringFound" != $"true" ]; then
    echo "$locationCode" >> locationCodeFile
    isLocationCodeDuplicate=false
  else
      isLocationCodeDuplicate=true
  fi
}

####################################
# printPhysicalFrameData
####################################
printPhysicalFrameData()
{
#  while read lineivar; do
#    if echo "$lineivar" |grep -q *SE; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
    ylxValue=`awk '/'"\*SE"'/ {print;exit }' tempstanza | cut -d " " -f2-`
      echo "PhysicalFrame.$physicalFrameindex.SerialNumber=$ylxValue"
      physicalFrameDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *TM; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
     ylxValue=`awk '/'"\*TM"'/ {print;exit }' tempstanza | cut -d " " -f2-`
      modelNumber=`echo $ylxValue | cut -d "-" -f2-`
      vendorType=`echo $ylxValue | cut -d "-" -f1`
      echo "PhysicalFrame.$physicalFrameindex.VendorType=$vendorType"
      echo "PhysicalFrame.$physicalFrameindex.Model=$modelNumber"
      physicalFrameDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *DS; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
     ylxValue=`awk '/'"\*DS"'/ {print;exit }' tempstanza | cut -d " " -f2-`
      echo "PhysicalFrame.$physicalFrameindex.Name=$ylxValue"
      physicalFrameDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *YL; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
     ylxValue=`awk '/'"\*YL"'/ {print;exit }' tempstanza | cut -d " " -f2-`
      echo "PhysicalFrame.$physicalFrameindex.Tag=$ylxValue"
      echo "$ylxValue#PhysicalFrame.$physicalFrameindex">>relationshipFile
      physicalFrameDataWritten=1
#    fi
#  done<tempstanza
  echo "PhysicalFrame.$physicalFrameindex.Manufacturer=IBM"
  echo "PhysicalFrame.$physicalFrameindex.RemovalConditions=2"

  if [ $physicalFrameDataWritten -eq 1 ]; then
    physicalFrameindex=`expr $physicalFrameindex + 1`
  fi
  physicalFrameDataWritten=0
  return
}

####################################
# printDiskData
####################################
printDiskData()
{
#  while read lineivar; do
#    if echo "$lineivar" |grep -q *DS; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*DS"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "PhysicalPackage.$physicalPackageindex.Name=$ylxValue"
      physicalPackageDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *TM; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*TM"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "PhysicalPackage.$physicalPackageindex.Model=$ylxValue"
      physicalPackageDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *YL; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*YL"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "PhysicalPackage.$physicalPackageindex.Tag=$ylxValue"
      echo "$ylxValue#PhysicalPackage.$physicalPackageindex">>relationshipFile
#    fi
#  done<tempstanza
  if [ $physicalPackageDataWritten -eq 1 ]; then
    physicalPackageindex=`expr $physicalPackageindex + 1`
  fi
  physicalPackageDataWritten=0
  return
}

####################################
# printCardData
####################################
printCardData()
{
 # while read lineivar; do
     ylxValue=`awk '/'"\*DS"'/ {print;exit }' tempstanza | cut -d " " -f2-` 
#    if echo "$lineivar" |grep -q *DS; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
      if echo "$ylxValue" | grep -iq memory; then
        echo "PhysicalMemory.$memoryIndex.Name=$ylxValue"
        memoryFound=1
        memoryDatawritten=1
      else
        memoryFound=0
        echo "Card.$pIndex.Name=$ylxValue"
        cardDataWritten=1
      fi
 #   fi
 ylxValue=`awk '/'"\*TM"'/ {print;exit }' tempstanza | cut -d " " -f2-`
   # if echo "$lineivar" |grep -q *TM; then
    #  ylxValue=`echo $lineivar | cut -d " " -f2-`
      if [ $memoryFound -eq 1 ]; then
        echo "PhysicalMemory.$memoryIndex.Model=$ylxValue"
        memoryDataWritten=1
      else
        echo "Card.$pIndex.Model=$ylxValue"
        cardDataWritten=1
      fi
#    fi
#    if echo "$lineivar" |grep -q *CC; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*CC"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      if [ $memoryFound -eq 1 ]; then
        echo "PhysicalMemory.$memoryIndex.VendorType=$ylxValue"
        memoryDatawritten=1
      else
        echo "Card.$pIndex.VendorType=$ylxValue"
        cardDataWritten=1
      fi
#    fi
#    if echo "$lineivar" |grep -q *SN; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*SN"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      if [ $memoryFound -eq 1 ]; then
        echo "PhysicalMemory.$memoryIndex.SerialNumber=$ylxValue"
        memoryDatawritten=1
      else
        echo "Card.$pIndex.SerialNumber=$ylxValue"
        cardDataWritten=1
      fi
#    fi
#    if echo "$lineivar" |grep -q *PN; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*PN"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      if [ $memoryFound -eq 1 ]; then
        echo "PhysicalMemory.$memoryIndex.PartNumber=$ylxValue"
        memoryDatawritten=1
      else
        echo "Card.$pIndex.PartNumber=$ylxValue"
        cardDataWritten=1
      fi
#    fi
#    if echo "$lineivar" |grep -q *FN; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*FN"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      if [ $memoryFound -eq 1 ]; then
        echo "PhysicalMemory.$memoryIndex.FRUNumber=$ylxValue"
        memoryDatawritten=1
      else
        echo "Card.$pIndex.FRUNumber=$ylxValue"
        cardDataWritten=1
      fi
#    fi

#    if echo "$lineivar" |grep -q *YL; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*YL"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      if [ $memoryFound -eq 1 ]; then
        echo "PhysicalMemory.$memoryIndex.Tag=$ylxValue"
        echo "$ylxValue#PhysicalMemory.$memoryIndex">>relationshipFile
        memoryDataWritten=1
      else
        echo "Card.$pIndex.Tag=$ylxValue"
        echo "$ylxValue#Card.$pIndex">>relationshipFile
        cardDataWritten=1
      fi
   # fi
 # done<tempstanza

  if [ $memoryFound -eq 1 ]; then
    echo "PhysicalMemory.$memoryIndex.ObjectType=PhysicalMemory"
    memoryDatawritten=1
  else
    echo "Card.$pIndex.ObjectType=Card"
    cardDataWritten=1
  fi
  if [ $memoryFound -eq 1 ]; then
    echo "PhysicalMemory.$memoryIndex.Manufacturer=IBM"
    memoryDatawritten=1
  else
    echo "Card.$pIndex.Manufacturer=IBM"
    cardDataWritten=1
  fi
  if [ $memoryFound -eq 1 ]; then
    memoryDatawritten=1
  else
    echo "Card.$pIndex.PackageType=9"
    cardDataWritten=1
  fi


  if [ $cardDataWritten -eq 1 ]; then
    pIndex=`expr $pIndex + 1`
  fi
  if [ $memoryFound -eq 1 ]; then
    if [ $memoryDataWritten -eq 1 ]; then 
      memoryIndex=`expr $memoryIndex + 1`
    fi
  fi
  cardDataWritten=0
  memoryDataWritten=0
  memoryFound=0
  return
}

####################################
# printPortData
####################################
printPortData()
{
#  while read lineivar; do
#    if echo "$lineivar" |grep -q *DS; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
    ylxValue=`awk '/'"\*DS"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "PhysicalPort.$portIndex.Name=$ylxValue"
      portDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *TM; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*TM"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "PhysicalPort.$portIndex.Model=$ylxValue"
      portDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *YL; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
    ylxValue=`awk '/'"\*YL"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "PhysicalPort.$portIndex.Tag=$ylxValue"
      echo "$ylxValue#PhysicalPort.$portIndex">>relationshipFile
#    fi
#  done<tempstanza
  if [ $portDataWritten -eq 1 ]; then
    portIndex=`expr $portIndex + 1`
  fi
  portDataWritten=0
  return
}

####################################
# printPlanerData
####################################
printPlanerData()
{
#  while read lineivar; do
#    if echo "$lineivar" |grep -q *PN; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*PN"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "Card.$pIndex.PartNumber=$ylxValue"
      cardDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *FN; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*FN"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "Card.$pIndex.FRUNumber=$ylxValue"
      cardDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *SN; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*SN"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "Card.$pIndex.SerialNumber=$ylxValue"
      cardDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *CD; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*CD"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "Card.$pIndex.Id=$ylxValue"
      cardDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *DS; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*DS"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "Card.$pIndex.Name=$ylxValue"
      cardDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *TM; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*TM"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo "Card.$pIndex.Model=$ylxValue"
      cardDataWritten=1
#    fi
#    if echo "$lineivar" |grep -q *YL; then
#      ylxValue=`echo $lineivar | cut -d " " -f2-`
 ylxValue=`awk '/'"\*YL"'/ {print;exit }' tempstanza  | cut -d " " -f2-`
      echo $ylxValue>>indexFile
      echo "Card.$pIndex.Tag=$ylxValue"
      echo "$ylxValue#Card.$pIndex">>relationshipFile
      cardDataWritten=1
#    fi
#  done<tempstanza

  echo "Card.$pIndex.ObjectType=Card"
  echo "Card.$pIndex.Manufacturer=IBM"
  echo "Card.$pIndex.PackageType=9"
  echo "Card.$pIndex.HostingBoard=True"
  cardDataWritten=1

  if [ $cardDataWritten -eq 1 ]; then
    pIndex=`expr $pIndex + 1`
  fi
  cardDataWritten=0
  return
}

####################################
# printTempVariable
####################################
printTempVariable()
{
  parseLocationCode
  return
}

####################################
# printRelationship
####################################
printRelationship()
{
  while read lineivar; do
    ylxValue=`echo $lineivar | cut -d "#" -f1`
    startStanza="*FC ????????"
    if [ "$lineivar" != "$startStanza" ]; then
      if echo "$ylxValue" |grep -q \-; then
        searchLocationCode=${lineivar%-*}
#        searchLocationCodeinFile
matchedLine=`awk '/'"$searchLocationCode"'/ {print;exit }' relationshipFile`
        ylxValue=`echo $lineivar | cut -d "#" -f2-`
        targetResource=`echo $ylxValue | cut -d "." -f1`
        targetIndex=`echo $ylxValue | cut -d "." -f2-`
        sourceResourceValue=`echo $matchedLine | cut -d "#" -f2-`
        sourceResource=`echo $sourceResourceValue | cut -d "." -f1`
        sourceIndex=`echo $sourceResourceValue | cut -d "." -f2-`
        echo Relationship.PPcontainsPE$relationshipIndex.ClassName=PhysicalPackageContainsPhysicalElement
        echo Relationship.PPcontainsPE$relationshipIndex.SourceClass=$sourceResource
        echo Relationship.PPcontainsPE$relationshipIndex.TargetClass=$targetResource
        echo PPcontainsPE$relationshipIndex.$relationshipIndex.SourceId=$sourceIndex
        echo PPcontainsPE$relationshipIndex.$relationshipIndex.TargetId=$targetIndex
        
        relationshipIndex=`expr $relationshipIndex + 1`
      fi
    fi
  done<relationshipFile
  return
}

####################################
# searchLocationCodeinFile
####################################
searchLocationCodeinFile()
{
  while read searchString; do
    searchStringValue=`echo $searchString | cut -d "#" -f1`
    if [ "$searchStringValue" == "$searchLocationCode" ]; then
      matchedLine=$searchString
    fi
  done<relationshipFile
  return
}

####################################
# main(String[] args)
####################################
echo "start time for linux script is `date`"
  os_arch=`uname -m`

  if [ "${os_arch#ppc}" != "$os_arch" ]; then
    printMetaInfo
    printPhysicalFrame
    printProcessors
    printDiskDrives
    printDiskPartitions
    printLogicalVolumes
    printFileSystems
    printNICs
    printlsvpd
    printTempVariable
    printRelationship
    rm -f tempstanza
    rm -f indexFile
    rm -f locationCodeFile
    rm -f relationshipFile
    rm -f teststr
    rm -f 0

  fi

echo "end time for linux script : `date`"



