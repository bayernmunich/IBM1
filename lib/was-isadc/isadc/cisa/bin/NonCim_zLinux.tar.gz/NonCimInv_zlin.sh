#!/bin/sh
# Licensed Materials - Property of IBM
#
# (C) Copyright IBM Corp. 2009, 2011 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplicate or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

####################################
# printPhysicalFrame
####################################
printPhysicalFrame()
{
  model=`cat /proc/sysinfo | grep 'Model:' | sed s/\ //g`
  machtype=`cat /proc/sysinfo | grep 'Type:' | sed s/\ //g`
  sequence=`cat /proc/sysinfo | grep 'Sequence Code:' | sed s/\ //g`
  plantnum=`cat /proc/sysinfo | grep 'Plant:' | sed s/\ //g`
  model=${model#Model:}
  machtype=${machtype#Type:}
  sequence=${sequence#SequenceCode:}
  plantnum=${plantnum#Plant:}
  serialnum=$plantnum$sequence
  model=${model:0:3}

  echo "PhysicalFrame.0.Name=IBM,$machtype-$model-$serialnum"
  echo "PhysicalFrame.0.Tag=U$machtype.$model.$serialnum"
  echo "PhysicalFrame.0.Manufacturer=IBM"
  echo "PhysicalFrame.0.Model=$model"
  echo "PhysicalFrame.0.VendorType=$machtype"
  echo "PhysicalFrame.0.SerialNumber=$serialnum"
  echo "PhysicalFrame.0.PackageType=3"
  return
}

####################################
# printProcessors
####################################
printProcessors()
{
  cat /proc/cpuinfo | grep 'processor ' | while read LINE
    do
      indexS=${LINE#*processor }
      cpuverS=${LINE#*version = }
      cpuuidS=${LINE#*identification = }
      cpumtmS=${LINE#*machine = }
      
      indexV=${indexS%%:*}
      cpuverV=${cpuverS%%,*}
      cpuuidV=${cpuuidS%%,*}
      cpumtmV=${cpumtmS%%,*}

      echo "Processor.$indexV.Name=proc$indexV"
      echo "Processor.$indexV.DeviceID=proc$indexV"
      echo "Processor.$indexV.UniqueID=$cpuuidV"
      echo "Processor.$indexV.Version=$cpuverV"
      echo "Processor.$indexV.AddressWidth=64"
      echo "Processor.$indexV.DataWidth=64"
      echo "Processor.$indexV.NumberOfEnabledCores=1"
      echo "Processor.$indexV.HealthState=1"
      echo "Processor.$indexV.OperatingState=8"
      echo "Processor.$indexV.Family=200"
    done
  return
}

####################################
# printDiskDrives
####################################
printDiskDrives()
{
  count=0
  for dasd_dir in /sys/bus/ccw/drivers/dasd*/*;
   do
     dasd_status=0
     dasd_subdir=${dasd_dir#/sys/bus/ccw/drivers/dasd*/}
     dasd_devid=hdisk${dasd_subdir#0.0.}
     echo "DiskDrive.$count.Name=$dasd_devid"
     echo "DiskDrive.$count.DeviceID=$dasd_devid"
     echo "DiskDrive.$count.DeviceType=2"
     if [ -f $dasd_dir/block/size ]; then
       dasd_size=`cat $dasd_dir/block/size`
       dasd_size=`expr $dasd_size / 2`
       echo "DiskDrive.$count.Capacity=$dasd_size"
     fi
     if [ -f $dasd_dir/online ]; then
       if [ `cat $dasd_dir/online` = "1" ]; then dasd_status=8
       else dasd_status=5
       fi
     fi
     echo "DiskDrive.$count.OperatingState=$dasd_status"
     count=`expr $count + 1`
  done
  return
}

####################################
# printDiskPartitions
####################################
printDiskPartitions()
{
  count=0
  cat /proc/partitions | grep 'dasd\|sd\|hd' | while read ONE TWO THREE FOUR FIVE
    do
      tempName=`echo $FOUR | grep '[0123456789]'`
      if [ "$tempName"  = "" ]; then
        continue
      fi
      echo "DiskPartition.$count.Name=/dev/$FOUR"
      echo "DiskPartition.$count.DeviceID=/dev/$FOUR"
      echo "DiskPartition.$count.NumberOfBlocks=$THREE"
      echo "DiskPartition.$count.Capacity=$THREE"
      echo "DiskPartition.$count.BlockSize=1"
      echo "DiskPartition.$count.PartitionType=2"
      echo "DiskPartition.$count.HealthState=1"
      count=`expr $count + 1`
    done
  return
}

####################################
# printLogicalVolumes
####################################
printLogicalVolumes()
{
  count=0
  cat /proc/partitions | grep 'dasd\|sd\|' | while read ONE TWO THREE FOUR FIVE
    do
      tempName=`echo $FOUR | grep '[0123456789]'`
      if [ "$tempName"  = "" ]; then
        continue
      fi
      echo "LogicalVolume.$count.Name=/dev/$FOUR"
      echo "LogicalVolume.$count.DeviceID=/dev/$FOUR"
      echo "LogicalVolume.$count.NumberOfBlocks=$THREE"
      echo "LogicalVolume.$count.Capacity=$THREE"
      echo "LogicalVolume.$count.BlockSize=1"
      echo "LogicalVolume.$count.HealthState=1"
      count=`expr $count + 1`
    done
  return
}

####################################
# printFileSystems
####################################
printFileSystems()
{
  count=0
  df -l -T -P -B 1 | sed '1d' | while read ONE TWO THREE FOUR FIVE SIX SEVEN
    do
      echo "FileSystem.$count.Name=$ONE"
      echo "FileSystem.$count.Root=$SEVEN"
      echo "FileSystem.$count.Label=$SEVEN"
      echo "FileSystem.$count.HealthState=1"
      echo "FileSystem.$count.AvailableSpace=$FIVE"
      echo "FileSystem.$count.FileSystemSize=$THREE"
      fsType="0"
      if [ "$TWO" = "jfs" ]; then fsType="1"; fi
      if [ "$TWO" = "nfs" ]; then fsType="25"; fi
      if [ "$TWO" = "ufs" ]; then fsType="19"; fi
      if [ "$TWO" = "vfs" ]; then fsType="9"; fi
      if [ "$TWO" = "xfs" ]; then fsType="23"; fi
      if [ "$TWO" = "udf" ]; then fsType="16"; fi
      if [ "$TWO" = "ext2" ]; then fsType="12"; fi
      if [ "$TWO" = "ext3" ]; then fsType="13"; fi
      if [ "$TWO" = "jfs2" ]; then fsType="3"; fi
      if [ "$TWO" = "ntfs" ]; then fsType="6"; fi
      if [ "$TWO" = "swap" ]; then fsType="22"; fi
      if [ "$TWO" = "fat16" ]; then fsType="8"; fi
      if [ "$TWO" = "fat32" ]; then fsType="7"; fi
      if [ "$TWO" = "namefs" ]; then fsType="26"; fi
      if [ "$TWO" = "reiserfs" ]; then fsType="14"; fi
      if [ "$TWO" = "linuxlvm" ]; then fsType="24"; fi
      echo "FileSystem.$count.FileSystemType=$fsType"
      count=`expr $count + 1`
    done
  return
}

####################################
# printDirectorAgent
####################################
printDirectorAgent()
{
  softwareName="IBM Director Core Services"
  softwareFile="/opt/ibm/director/version.lv1"
  if [ -f "/opt/ibm/director/version.key" ]; then
    softwareName="IBM Director Platform Agent"
    softwareFile="/opt/ibm/director/version.key"
  else
    if [ -f "/opt/ibm/platform/version.lv1" ]; then
      softwareName="IBM Director Platform Agent"
      softwareFile="/opt/ibm/platform/version.lv1"
    fi
  fi
  if [ -f $softwareFile ]; then
    echo "DirectorAgent.0.Name=$softwareName"
    echo "DirectorAgent.0.DisplayName=$softwareName"
    echo "DirectorAgent.0.Description=$softwareName"
    echo "DirectorAgent.0.Vendor=IBM"
    echo "DirectorAgent.0.InstalledLocation=Director_Root"
    echo "DirectorAgent.0.Category=3"
    echo "DirectorAgent.0.SubCategory=Director"
    for LINE in `cat $softwareFile`; 
      do
        first=${LINE%*=*}
        second=${LINE#*=*}
        if [ "$first" = "version" ]; then
          echo "DirectorAgent.0.Version=$second"
        fi
#       if [ "$first" = "builddate" ]; then
#         echo "DirectorAgent.0.BuildDate=$second"
#       fi
        if [ "$first" = "buildnum" ]; then
          echo "DirectorAgent.0.BuildNumber=$second"
        fi
    done    
  fi
  return
}

####################################
# printNICs
####################################
printNICs()
{
  count=0
  lancount=0
  devicelist=`ifconfig | grep "Link encap" | sed /"Local Loopback"/d | cut -d ' ' -f 1`

  for netdevice in $devicelist
   do
    ipaddress=`ifconfig $netdevice | grep "inet addr" | tr -s ' ' ',' | cut -d , -f 3 | sed 's/addr://'`
    ipv6=`ifconfig $netdevice | grep "inet6 addr" | tr -s ' ' ',' | cut -d , -f 4 | sed 's/addr://'`
    subnetmask=`ifconfig $netdevice | grep "inet addr" | tr -s ' ' ',' | cut -d , -f 5 | sed 's/Mask://'`
    netdevice_stripped=`echo "$netdevice" | cut -d : -f 1`
    gateway=`route -n | grep "$netdevice_stripped" | grep "UG" | tr -s ' ' ',' | cut -d , -f 2`
    macaddrLine=`ifconfig $netdevice | grep "HWaddr"`
    macaddress=${macaddrLine#*HWaddr }
    macaddress=`echo $macaddress | sed s/://g`
    
    if [ "$ipv6" != "" ]; then
      for ip6info in $ipv6
      do
        prefixlen=${ip6info#*/}
        ip6address=${ip6info%/*}   
        echo "CSIPProtocolEndpoint.$count.Name=$ip6address"
        echo "CSIPProtocolEndpoint.$count.Gateway=$gateway"
        echo "CSIPProtocolEndpoint.$count.IPv6Address=$ip6address"
        echo "CSIPProtocolEndpoint.$count.PrefixLength=$prefixlen" 
        echo "CSIPProtocolEndpoint.$count.HostType=CS"
        echo "OSIPProtocolEndpoint.$count.Name=$ip6address"
        echo "OSIPProtocolEndpoint.$count.Gateway=$gateway"
        echo "OSIPProtocolEndpoint.$count.IPv6Address=$ip6address"
        echo "OSIPProtocolEndpoint.$count.PrefixLength=$prefixlen"
        echo "OSIPProtocolEndpoint.$count.HostType=OS"
        echo "CSBindsTo.$count.SourceId=$count"
        echo "CSBindsTo.$count.TargetId=$lancount"
        echo "OSBindsTo.$count.SourceId=$count"
        echo "OSBindsTo.$count.TargetId=$lancount"
        count=`expr $count + 1`
      done
    fi
    if [ "$ipaddress" != "" ]; then
      echo "CSIPProtocolEndpoint.$count.Name=$ipaddress"
      echo "CSIPProtocolEndpoint.$count.Gateway=$gateway"
      echo "CSIPProtocolEndpoint.$count.SubnetMask=$subnetmask"
      echo "CSIPProtocolEndpoint.$count.IPv4Address=$ipaddress"
      echo "CSIPProtocolEndpoint.$count.HostType=CS"
      echo "OSIPProtocolEndpoint.$count.Name=$ipaddress"
      echo "OSIPProtocolEndpoint.$count.Gateway=$gateway"
      echo "OSIPProtocolEndpoint.$count.SubnetMask=$subnetmask"
      echo "OSIPProtocolEndpoint.$count.IPv4Address=$ipaddress"
      echo "OSIPProtocolEndpoint.$count.HostType=OS"
      echo "CSBindsTo.$count.SourceId=$count"
      echo "CSBindsTo.$count.TargetId=$lancount"
      echo "OSBindsTo.$count.SourceId=$count"
      echo "OSBindsTo.$count.TargetId=$lancount"
      count=`expr $count + 1`
    fi
    if [ "$ipaddress" != "" ] || [ "$ip6info" != "" ]; then
      echo "CSLANEndpoint.$lancount.Name=$macaddress"
      echo "CSLANEndpoint.$lancount.DisplayName=$netdevice_stripped"
      echo "CSLANEndpoint.$lancount.DeviceName=$netdevice_stripped"
      echo "CSLANEndpoint.$lancount.MACAddress=$macaddress"
      echo "CSLANEndpoint.$lancount.HostType=CS"
      echo "OSLANEndpoint.$lancount.Name=$macaddress"
      echo "OSLANEndpoint.$lancount.DisplayName=$netdevice_stripped"
      echo "OSLANEndpoint.$lancount.DeviceName=$netdevice_stripped"
      echo "OSLANEndpoint.$lancount.MACAddress=$macaddress"
      echo "OSLANEndpoint.$lancount.HostType=OS"
      lancount=`expr $lancount + 1`
    fi

  done
  return
}

####################################
# printMetaInfo
####################################
printMetaInfo()
{
# --PhysicalFrame-- #
  echo "Resource.PhysicalFrame.ClassName=PhysicalFrame"
  echo "Resource.PhysicalFrame.Keys=Tag"
  echo "Relationship.PhysicalFrameCS.ClassName=ComputerSystemContainsPhysicalElement"
  echo "Relationship.PhysicalFrameCS.Implicit=true"
  echo "Relationship.PhysicalFrameCS.SourceClass=Server"
  echo "Relationship.PhysicalFrameCS.TargetClass=PhysicalFrame"
# --Processor-- #
  echo "Resource.Processor.ClassName=Processor"
  echo "Resource.Processor.Keys=DeviceID"
  echo "Relationship.ProcessorCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.ProcessorCS.Implicit=true"
  echo "Relationship.ProcessorCS.SourceClass=Server"
  echo "Relationship.ProcessorCS.TargetClass=Processor"
# --DiskDrive-- #
  echo "Resource.DiskDrive.ClassName=DiskDrive"
  echo "Resource.DiskDrive.Keys=DeviceID"
  echo "Relationship.DiskDriveCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.DiskDriveCS.Implicit=true"
  echo "Relationship.DiskDriveCS.SourceClass=Server"
  echo "Relationship.DiskDriveCS.TargetClass=DiskDrive"
# --DiskPartition-- #
  echo "Resource.DiskPartition.ClassName=DiskPartition"
  echo "Resource.DiskPartition.Keys=DeviceID"
  echo "Relationship.DiskPartitionCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.DiskPartitionCS.Implicit=true"
  echo "Relationship.DiskPartitionCS.SourceClass=Server"
  echo "Relationship.DiskPartitionCS.TargetClass=DiskPartition"
# --LogicalVolume-- #
  echo "Resource.LogicalVolume.ClassName=LogicalVolume"
  echo "Resource.LogicalVolume.Keys=DeviceID"
  echo "Relationship.LogicalVolumeCS.ClassName=ComputerSystemContainsLogicalDevice"
  echo "Relationship.LogicalVolumeCS.Implicit=true"
  echo "Relationship.LogicalVolumeCS.SourceClass=Server"
  echo "Relationship.LogicalVolumeCS.TargetClass=LogicalVolume"
# --FileSystem-- #
  echo "Resource.FileSystem.ClassName=FileSystem"
  echo "Resource.FileSystem.Keys=Name"
  echo "Relationship.FileSystemCS.ClassName=ComputerSystemContainsFileSystem"
  echo "Relationship.FileSystemCS.Implicit=true"
  echo "Relationship.FileSystemCS.SourceClass=Server"
  echo "Relationship.FileSystemCS.TargetClass=FileSystem"
# --DirectorAgent-- #
  echo "Resource.DirectorAgent.ClassName=SoftwareInstallation"
  echo "Resource.DirectorAgent.Keys=Name,Version"
  echo "Relationship.DirectorAgentCS.ClassName=SoftwareResourceInstalledOnComputerSystem"
  echo "Relationship.DirectorAgentCS.Implicit=true"
  echo "Relationship.DirectorAgentCS.SourceClass=SoftwareInstallation"
  echo "Relationship.DirectorAgentCS.SourceAlias=DirectorAgent"
  echo "Relationship.DirectorAgentCS.TargetClass=Server"
# --NICs-- #
  echo "Resource.CSLANEndpoint.ClassName=LANEndpoint"
  echo "Resource.CSLANEndpoint.Keys=Name,HostType"
  echo "Resource.OSLANEndpoint.ClassName=LANEndpoint"
  echo "Resource.OSLANEndpoint.Keys=Name,HostType"
  echo "Resource.CSIPProtocolEndpoint.ClassName=IPProtocolEndpoint"
  echo "Resource.CSIPProtocolEndpoint.Keys=Name,HostType"
  echo "Resource.OSIPProtocolEndpoint.ClassName=IPProtocolEndpoint"
  echo "Resource.OSIPProtocolEndpoint.Keys=Name,HostType"
  echo "Relationship.LANEndpointCS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.LANEndpointCS.Implicit=true"
  echo "Relationship.LANEndpointCS.SourceClass=Server"
  echo "Relationship.LANEndpointCS.TargetClass=LANEndpoint"
  echo "Relationship.LANEndpointCS.TargetAlias=CSLANEndpoint"
  echo "Relationship.IPProtocolEndpointCS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointCS.Implicit=true"
  echo "Relationship.IPProtocolEndpointCS.SourceClass=Server"
  echo "Relationship.IPProtocolEndpointCS.TargetClass=IPProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointCS.TargetAlias=CSIPProtocolEndpoint"
  echo "Relationship.LANEndpointOS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.LANEndpointOS.Implicit=true"
  echo "Relationship.LANEndpointOS.SourceClass=OperatingSystem"
  echo "Relationship.LANEndpointOS.TargetClass=LANEndpoint"
  echo "Relationship.LANEndpointOS.TargetAlias=OSLANEndpoint"
  echo "Relationship.IPProtocolEndpointOS.ClassName=SystemHostsProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointOS.Implicit=true"
  echo "Relationship.IPProtocolEndpointOS.SourceClass=OperatingSystem"
  echo "Relationship.IPProtocolEndpointOS.TargetClass=IPProtocolEndpoint"
  echo "Relationship.IPProtocolEndpointOS.TargetAlias=OSIPProtocolEndpoint"
  echo "Relationship.CSBindsTo.ClassName=ProtocolEndpointBindsToProtocolEndpoint"
  echo "Relationship.CSBindsTo.SourceClass=IPProtocolEndpoint"
  echo "Relationship.CSBindsTo.SourceAlias=CSIPProtocolEndpoint"
  echo "Relationship.CSBindsTo.TargetClass=LANEndpoint"
  echo "Relationship.CSBindsTo.TargetAlias=CSLANEndpoint"
  echo "Relationship.OSBindsTo.ClassName=ProtocolEndpointBindsToProtocolEndpoint"
  echo "Relationship.OSBindsTo.SourceClass=IPProtocolEndpoint"
  echo "Relationship.OSBindsTo.SourceAlias=OSIPProtocolEndpoint"
  echo "Relationship.OSBindsTo.TargetClass=LANEndpoint"
  echo "Relationship.OSBindsTo.TargetAlias=OSLANEndpoint"
  return
}

####################################
# main(String[] args)
####################################
  os_arch=`uname -m`

  if [ "${os_arch#s390}" != "$os_arch" ]; then
    printMetaInfo
    printPhysicalFrame
    printProcessors
    printDiskDrives
    printDiskPartitions
    printLogicalVolumes
    printFileSystems
    printDirectorAgent
    printNICs
  fi