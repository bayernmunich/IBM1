/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


/*=====
// dijit fallback for key summaries otherwise not covered by the doc parser

dijit.demos = {
	// summary:
	//		Home of the official dijit demo code
};

dijit.form = {
	// summary:
	//		Form and input related widgets
};

dijit.layout = {
	// summary:
	//		Layout related widgets
};
=====*/
